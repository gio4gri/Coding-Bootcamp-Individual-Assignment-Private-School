package school.entities;


public class Trainer {

    private int id;
    private String fname;
    private String lname;
    private String subj;
    private String user;
    private String pass;

    public Trainer(int id, String fname, String lname, String subj) {
        this.id = id;
        this.fname = fname;
        this.lname = lname;
        this.subj = subj;
    }

  

    public Trainer() {
    }

    public String getPass() {
        return pass;
    }

    public String getUser() {
        return user;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    public void setUser(String user) {
        this.user = user;
    }
    
    
    
    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getFname() {
        return fname;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }

    public String getLname() {
        return lname;
    }
    
    public void setSubj(String subj){
        this.subj = subj;
    }
    
    public String getSubj() {
        return subj;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    @Override
    public String toString() {
        return "Trainer[ " + fname + ", " + lname + ", Subject=" + subj + ']';
    }

   
    
    
    
}