package school.entities;

import java.util.ArrayList;
import school.entities.Course;
import school.entities.Student;

public class StudentsPerCourse {
    
    private int id;
    private Course course;
    private Student student;
    private ArrayList<Student> studentPerCourseList;

    public StudentsPerCourse(int id, Course course, Student student, ArrayList<Student> studentPerCourseList) {
        this.id = id;
        this.course = course;
        this.student = student;
      //  this.studentPerCourseList = studentPerCourseList;
    }

  

    public StudentsPerCourse() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }
    
    
    
    public void setCourse(Course course) {
        this.course = course;
    }

    public void setStudentPerCourseList(ArrayList<Student> studentPerCourseList) {
        this.studentPerCourseList = studentPerCourseList;
    }

    public Course getCourse() {
        return course;
    }

    public ArrayList<Student> getStudentPerCourseList() {
        return studentPerCourseList;
    }

    @Override
    public String toString() {
        return "{" 
                + "id=" + id
                + ", course=" + course
                +"\n,student=" + student
                //+ ", studentPerCourseList=" + studentPerCourseList 
                + '}';
    }

    

    
}
