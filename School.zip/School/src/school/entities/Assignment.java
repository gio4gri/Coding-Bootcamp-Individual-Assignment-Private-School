package school.entities;


public class Assignment {
    private int id;
    private String title;
    private String descr;
    
    private String date;
 
    private int mark;

    public Assignment() {
    }

    public Assignment(int id, String title, String descr, String date, int mark) {
        this.id = id;
        this.title = title;
        this.descr = descr;
        this.date = date;
        this.mark = mark;

    } 

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
    

    public void setTitle(String title){
        this.title = title;
    }

    public String getTitle(){
        return title;
    }

    public void setDescr(String descr){
        this.descr = descr;
    }

    public String getDescr(){
        return descr;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getDate() {
        return date;
    }

    public void setMark(int mark) {
        this.mark = mark;
    }

    public int getMark() {
        return mark;
    }

    @Override
    public String toString() {
        return "Assignment[ " + title + ", " + descr + ", Submission Date=" + date + ", Total Mark=" + mark + "]";
    }

}
