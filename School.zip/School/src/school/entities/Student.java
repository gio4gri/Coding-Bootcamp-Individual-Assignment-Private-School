package school.entities;

import java.util.ArrayList;
import java.util.Date;
import java.util.ArrayList;


public class Student {
    private int id;
    private String fname;
    private String lname;
    private String bday;
    private int fees;
    private String user;
    private String pass;
    
    
    

    public Student(int id, String fname, String lname, String bday, int fees) {
        this.id = id;
        this.fname = fname;
        this.lname = lname;
        this.bday = bday;
        this.fees = fees;
    }
     
  

    public Student() {
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    public void setUser(String user) {
        this.user = user;
    }

//    public String getPass() {
//        return pass;
//    }

    public String getUser() {
        return user;
    }
    
    
    
    
    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getFname() {
        return fname;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }

    public String getLname() {
        return lname;
    }

public void setBday(String bday) {
        this.bday = bday;
    }

    public String getBday() {
        return bday;
    }

    public void setFees(int fees) {
        this.fees = fees;
    }

    public int getFees() {
        return fees;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    @Override
    public String toString() {
        return "Student[ "  + fname + ", " + lname + ", Birthday=" + bday + ", Fees=" + fees + ']';
    }   
    
}
