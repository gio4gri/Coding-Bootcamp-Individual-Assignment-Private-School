package school.entities;

import java.util.ArrayList;

public class TrainersPerCourse {
    
    private int id;
    private Course course;
    private Trainer trainer;
    
    private ArrayList<Trainer> trainerPerCourseList;
    private static int numberOfTrainersPerCourse = 0;

    public TrainersPerCourse() {
    }

    public TrainersPerCourse(int id, Course course, Trainer trainer/*, ArrayList<Trainer> trainerPerCourseList*/) {
        this.id = id;
        this.course = course;
        this.trainer = trainer;
        //this.trainerPerCourseList = trainerPerCourseList;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Trainer getTrainer() {
        return trainer;
    }

    public void setTrainer(Trainer trainer) {
        this.trainer = trainer;
    }

   

    public void setCourse(Course course) {
        this.course = course;
    }

    public void setTrainerPerCourseList(ArrayList<Trainer> trainerPerCourseList) {
        this.trainerPerCourseList = trainerPerCourseList;
    }

    public Course getCourse() {
        return course;
    }

    public ArrayList<Trainer> getTrainerPerCourseList() {
        return trainerPerCourseList;
    }

    public static int getNumberOfTrainersPerCourse() {
        return numberOfTrainersPerCourse;
    }

    @Override
    public String toString() {
        return "TrainersPerCourse{" + "id=" + id + ", course=" + course + ", \n\ttrainer=" + trainer + /*", trainerPerCourseList=" + trainerPerCourseList + */ "}\n";
    }
   
    
}

