package school.entities;

import java.util.ArrayList;

public class AssignmentsPerCourse {

private int id;
private Course course;
private Assignment assignment;
private ArrayList<Assignment> assignmentsPerCourseList;
private static int numberOfAssignmentsPerCourse = 0;

    public AssignmentsPerCourse() {
        numberOfAssignmentsPerCourse++;
    }

    public AssignmentsPerCourse(Course course, ArrayList<Assignment> assignmentsPerCourseList) {
        this.course = course;
        this.assignmentsPerCourseList = assignmentsPerCourseList;
        numberOfAssignmentsPerCourse++;
    }

    public void setAssignment(Assignment assignment) {
        this.assignment = assignment;
    }

    public Assignment getAssignment() {
        return assignment;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setAssignmentsPerCourseList(ArrayList<Assignment> assignmentsPerCourseList) {
        this.assignmentsPerCourseList = assignmentsPerCourseList;
    }

    public void setCourse(Course course) {
        this.course = course;
    }

    public ArrayList<Assignment> getAssignmentsPerCourseList() {
        return assignmentsPerCourseList;
    }

    public Course getCourse() {
        return course;
    }

    public static int getNumberOfAssignmentsPerCourse() {
        return numberOfAssignmentsPerCourse;
    }

    @Override
    public String toString() {
        return "AssignmentsPerCourse{ "+ "Course=" + course + ", \n\tAssignment=" + assignment + /*", assignmentsPerCourseList=" + assignmentsPerCourseList + */'}';
    }

  
 
    public String toString2(Course course, ArrayList<Assignment> assignmentsPerCourseList) {
        return "AssignmentsPerCourse{" + " course=" + course + ", assignmentsPerCourseList=" + assignmentsPerCourseList + '}';
    }


    
}
