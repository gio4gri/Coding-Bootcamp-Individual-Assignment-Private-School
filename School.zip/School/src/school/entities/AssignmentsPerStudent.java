package school.entities;

import com.sun.org.apache.xalan.internal.xsltc.cmdline.getopt.GetOpt;
import java.util.ArrayList;
import java.util.Date;


public class AssignmentsPerStudent {

    private int id;
    private Student student;
    private Assignment assignment;
    private Course course;
    private boolean submitted;
   
    private int mark;
    
    private ArrayList<Assignment> assignmentsPerStudentList;
    
    
    
    private static int numOfAssignmentsPerStudent = 0;

    
    public AssignmentsPerStudent() {
    }

    public AssignmentsPerStudent(int id, Student student, Assignment assignment, Course course, boolean submitted, int mark/*, ArrayList<Assignment> assignmentsPerStudentList*/) {
        this.id = id;
        this.student = student;
        this.assignment = assignment;
        this.course = course;
        this.submitted = submitted;
        this.mark = mark;
       // this.assignmentsPerStudentList = assignmentsPerStudentList;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setSubmitted(boolean submitted) {
        this.submitted = submitted;
    }

    public boolean getSubmitted(){
        return submitted;
    }
    
    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }

    public Course getCourse() {
        return course;
    }

    public void setCourse(Course course) {
        this.course = course;
    }

    public Assignment getAssignment() {
        return assignment;
    }

    public void setAssignment(Assignment assignment) {
        this.assignment = assignment;
    }

   
    
    
    public int getMark() {
        return mark;
    }

    public void setMark(int mark) {
        this.mark = mark;
    }

    
    
    
    
    public ArrayList<Assignment> getAssignmentsPerStudentList() {
        return assignmentsPerStudentList;
    }

    public void setAssignmentsPerStudentList(ArrayList<Assignment> assignmentsPerStudentList) {
        this.assignmentsPerStudentList = assignmentsPerStudentList;
    }

    

    public static int getNumOfAssignmentsPerStudent() {
        return numOfAssignmentsPerStudent;
    }

    @Override
    public String toString() {
        return "AssignmentsPerStudent{" + "id=" + id + ", student=" + student + ", assignment=" + assignment + ", course=" + course + ", submitted=" + submitted + ", mark=" + mark + "}\n";
    }

   
  
    
}
