package school;

import Dao.AssignmentDao;
import Dao.AssignmentsPerCourseDao;
import Dao.AssignmentsPerStudentDao;
import Dao.CheckIdDao;
import Dao.CourseDao;
import Dao.StudentDao;
import Dao.StudentPerCourseDao;
import Dao.TrainerDao;
import Dao.TrainersPerCourseDao;
import com.mysql.cj.x.protobuf.Mysqlx;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalField;
import java.time.temporal.WeekFields;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import jdk.nashorn.internal.parser.TokenType;
import school.entities.Assignment;
import school.entities.AssignmentsPerCourse;
import school.entities.*;
import sun.awt.AWTAccessor;

/**
 *
 * @author George
 */
public class MainClass {

    private static Scanner input = new Scanner(System.in);
    
    private static DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    
    private static int numberOfTries = 0;

    public static void main(String[] args) {

       MainClass school = new MainClass();
        System.out.println("\n\n#################### START ####################\n\n");

       System.out.println("Welcome to our school!\n");
       int[] dataArr = {0,0};    
       do{
           
                System.out.print("\nEnter your username: ");
                String user = school.getStringInput(input);

                System.out.print("\nEnter your password: ");
                String pass = input.next();

                
                dataArr = school.loginScreenOption(user,pass);

                 if (dataArr[0] == 1){
                     school.studentMenu(dataArr[1]);
                 } else if (dataArr[0] == 2){
                     school.trainerMenu(dataArr[1]);
                 } else if (dataArr[0] == 3) {
                     school.headMasterMenu();
                 } else {
                       
                        if (numberOfTries == 2){
                            System.out.println("You have "+(3-numberOfTries)+" last try left!");
                        } else  {
                        System.out.println("You have "+(3-numberOfTries)+" tries left.");
                        }
                 }
       } while((numberOfTries<3) && (dataArr[0]==0));
       
       if (numberOfTries>3){
           System.out.println("\nYou have no more tries left!\nGoodbye!");
       }


          System.out.println("\n\n#################### END ####################\n\n");
    }

////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////
    
    private int[] loginScreenOption(String username, String password) {
       int[] dataArr = new int[2];
        CheckIdDao checkDao = new CheckIdDao();
        int role = 0;
        int id = 0;
        int id1, id2, id3 = 0;
                
        password = hashingPassword(password);
        
        id1 = checkDao.checkStudentId(username, password);
        id2 = checkDao.checkTrainerId(username, password);
        id3 = checkDao.checkHeadMasterId(username, password);
        if ( id1 > 0 ) {
           role = 1;
           id = id1;
        } else if ( id2 > 0 ) {
            role = 2;
            id = id2;
        } else if ( id3 > 0 ){
            role = 3;
            id = id3;
        } else {
            System.out.println("Wrong Username or Password!");
            numberOfTries++;
        }
  
        dataArr[0] = role;
        dataArr[1] = id;
        return dataArr;
    }

    private String hashingPassword(String password){
// online source       
// https://howtodoinjava.com/security/how-to-generate-secure-password-hash-md5-sha-pbkdf2-bcrypt-examples/ 
       
         String passwordToHash = password;
        String generatedPassword = null;
        try {
            // Create MessageDigest instance for MD5
            MessageDigest md = MessageDigest.getInstance("MD5");
            //Add password bytes to digest
            md.update(passwordToHash.getBytes());
            //Get the hash's bytes
            byte[] bytes = md.digest();
            //This bytes[] has bytes in decimal format;
            //Convert it to hexadecimal format
            StringBuilder sb = new StringBuilder();
            for(int i=0; i< bytes.length ;i++)
            {
                sb.append(Integer.toString((bytes[i] & 0xff) + 0x100, 16).substring(1));
            }
            //Get complete hashed password in hex format
            generatedPassword = sb.toString();
        }
        catch (NoSuchAlgorithmException e)
        {
            e.printStackTrace();
        }
        
//        System.out.println(generatedPassword);
//        System.out.println(passwordToHash);
//        
        return (generatedPassword) ;
    } 
    
    
     private boolean passwordValidationOk(String password){
       // https://www.javacodeexamples.com/check-password-strength-in-java-example/668
       
        
        if( password.length() < 5 ){
             System.out.println("Password should be at least 5 characters long.");
            return false;}
       else if( password.length() > 10 ){
            System.out.println("Password should be 10 characters long the most.");
            return false;}
        //if it contains one lower case letter
       else if( !password.matches("(?=.*[a-z]).*") ){
            System.out.println("Password should contain at least one lower case letter.");
            return false;}
        //if it contains one upper case letter
       else if(! password.matches("(?=.*[A-Z]).*") ){
            System.out.println("Password should contain at least one upper case letter.");
            return false;}
        //if it contains one digit
       else if(! password.matches("(?=.*[0-9]).*") ){
             System.out.println("Password should contain at least one digit.");
            return false;}
        //if it contains one special character
        else if (!password.matches("(?=.*[~!@#$%^&*()_-]).*")){
           System.out.println("Password should contain at least one special character.");
           return false;}
        
        return true;
        
    }
    
    private String getStringInput(Scanner in){
        String enteredValue = in.next();
       enteredValue = enteredValue.trim();
       enteredValue = enteredValue.toLowerCase();
        return enteredValue;
    }
     
    private int getInput(Scanner in) {
        while (!(in.hasNextInt())) {
            System.out.print("Please insert a number: ");
            in.next();
        }
        int g = in.nextInt();
        return g;
    }

    private void studentMenu(int id) {
        StudentDao sDao = new StudentDao();
        StudentPerCourseDao spcDao;
        AssignmentsPerCourseDao apcDao;
         CourseDao cDao = new CourseDao();
          int i, idx, cid, apsid, aid;
        System.out.println("\nWelcome "+sDao.getStudentById(id).getFname()+" "+sDao.getStudentById(id).getLname()+" !");
        do {
            System.out.println("\n-----MAIN MENU-----\n");
            System.out.println("\nPlease insert a number for one of the following options.");
            System.out.println("[1]: Check your schedule.");
            System.out.println("[2]: See the dates of submission of the Assignments per Course");
            System.out.println("[3]: Submit your Assignments.");
            System.out.print("Enter your option here: ");
            
            int option = getInput(input);
            while (!(option == 1 || option == 2 || option == 3)) {
                System.out.print("\nPlease select a number between [1],[2],[3]: ");
                option = getInput(input);
            }

          
            

            switch (option) {
                case 1:
                    
               spcDao = new StudentPerCourseDao();
               i = 0; idx =0;  cid =0;
                  
               System.out.println("\nPlease select the course you want to check:");
//              
                 
                  ArrayList<Course> clist = new ArrayList<Course>();
                
                clist = spcDao.getCoursesperStudentById(id);
                i=1;
                for (Course c : clist) {
                    System.out.println("["+i+"]: "+c);
                    i++;
                }
                
                System.out.print("Enter your option here: ");
                    idx = getInput(input);
                    
                    while (idx > clist.size() || idx < 0) {
                        System.out.print("\nPlease select a valid number: ");
                        idx = getInput(input);
                    }
                    cid = clist.get(idx-1).getId(); 
                    
                    schedulePerCourse(cid);
                      
                    break;

                case 2:
                    System.out.println("\nHere is your submission dates for your assignments per course");
                    spcDao = new StudentPerCourseDao();
                    ArrayList<Course> list8 = new ArrayList<Course>();
                    list8 = spcDao.getCoursesperStudentById(id);

                    apcDao = new AssignmentsPerCourseDao();

                    for (Course course : list8) {
                        System.out.println(course);
                        for (Assignment assignment : (apcDao.getAssignmentsPerCourseById(course.getId()))) {
                            System.out.println("Assignment: " + assignment.getTitle() + ", \tsubmission date: " + assignment.getDate());
                        }
                    }
                    break;

                case 3:

                    System.out.println("\nHere is a list of all your assignments.");

                    AssignmentDao aDao = new AssignmentDao();
                    AssignmentsPerStudentDao apsDao = new AssignmentsPerStudentDao();

                    ArrayList<AssignmentsPerStudent> apslist = new ArrayList<AssignmentsPerStudent>();

                    apslist = apsDao.getListOfAssignmentsPerStudentId(id);
                    i = 1;
                    for (AssignmentsPerStudent aps : apslist) {
                        System.out.println("[" + i + "]: " + aps.getAssignment().getTitle() + ", " + aps.getAssignment().getDescr() + ", submission date:" + aps.getAssignment().getDate() + ", submitted: " + aps.getSubmitted());
                        i++;
                    }

                    System.out.print("Enter your option here: ");
                    idx = getInput(input);

                    while (idx > apslist.size() || idx < 0) {
                        System.out.print("\nPlease select a valid number: ");
                        idx = getInput(input);
                    }
                    aid = apslist.get(idx - 1).getAssignment().getId();
                   
                    
                    System.out.println(apsDao.getListOfAssignmentsPerStudentId(id).get(idx-1).getAssignment());
                    
                    System.out.print("Do you want to proceed? [y]or[n]: ");
                        if ((!(input.next()).equals("n"))){
                     apsDao.updateAssignmentPerStudentById(id, aid);
                        } else System.out.println("Submit was canceled.\n");
                   
                   
                    
                    
                    apslist = apsDao.getListOfAssignmentsPerStudentId(id);
                    i = 1;
                    for (AssignmentsPerStudent aps : apslist) {
                        System.out.println("[" + i + "]: " + aps.getAssignment().getTitle() + ", " + aps.getAssignment().getDescr() + ", submission date:" + aps.getAssignment().getDate() + ", submitted: " + aps.getSubmitted());
                        i++;
                    }
                    
                    break;

            }

            System.out.print("\nDo you want to go back to the Main Menu? [y] or [n] : ");
        } while ((!(input.next()).toLowerCase().equals("n")));
    }

    private void trainerMenu(int tid) {
         TrainersPerCourseDao tpcDao = new TrainersPerCourseDao();
            StudentPerCourseDao spcDao = new StudentPerCourseDao();
            AssignmentsPerStudentDao apsDao = new AssignmentsPerStudentDao();
            AssignmentDao aDao = new AssignmentDao();
            StudentDao sDao = new StudentDao();
            CourseDao cDao = new CourseDao();
            TrainerDao tDao = new TrainerDao();
            cDao = new CourseDao();
            ArrayList<Course> clist = new ArrayList<Course>();
            int i, idx, cid, sid, aid, apsid ;
                System.out.println("\nWelcome "+tDao.getTrainerById(tid).getFname()+" "+tDao.getTrainerById(tid).getLname()+" !");

            
        do {
            System.out.println("\n-----MAIN MENU-----\n");
            System.out.println("Please insert a number for one of the following options.");
            System.out.println("[1]: View all the courses you are teaching.");
            System.out.println("[2]: View all the students for each Course.");
            System.out.println("[3]: View all the assignments per student for each course.");
            System.out.println("[4]: Mark all the assignments per student for each course.");
            System.out.print("Enter your option here: ");
            
            int option = getInput(input);
            while (!(option == 1 || option == 2 || option == 3 || option == 4)) {
                System.out.print("\nPlease select a number between [1],[2],[3],[4]: ");
                option = getInput(input);
            }

           

            switch (option) {

                case 1:

                    tpcDao = new TrainersPerCourseDao();
                    spcDao = new StudentPerCourseDao();
                    apsDao = new AssignmentsPerStudentDao();
                    
                    if (tpcDao.getCoursesPerTrainerById(tid).isEmpty()){
                        System.out.println("This Trainer is not yet appointed to any course.");
                    } else {
                    System.out.println("\nHere is the list of all the courses you are teaching.");
                        
                    for (Course c : tpcDao.getCoursesPerTrainerById(tid)) {
                            System.out.println(c);
                        }
                   }
                    break;

                case 2:

                    tpcDao = new TrainersPerCourseDao();
                    spcDao = new StudentPerCourseDao();
                    apsDao = new AssignmentsPerStudentDao();

                    if (tpcDao.getCoursesPerTrainerById(tid).isEmpty()) {
                        System.out.println("This Trainer is not yet appointed to any course.");
                    } else {
                        System.out.println("\nHere is the list of all the students for each of your courses.");

                        for (Course c : tpcDao.getCoursesPerTrainerById(tid)) {
                            System.out.println("\n"+c);
                            if (spcDao.getStudentsPerCourseById(c.getId()).isEmpty()) {
                                System.out.println("This course has no students enrolled yet.");
                            } else {
                                for (Student s : spcDao.getStudentsPerCourseById(c.getId())) {
                                    System.out.println(s.getFname()+" "+s.getLname());
                                }

                            }
                        }
                    }
                    break;

                case 3:
                    tpcDao = new TrainersPerCourseDao();
                    spcDao = new StudentPerCourseDao();
                    apsDao = new AssignmentsPerStudentDao();

                    if (tpcDao.getCoursesPerTrainerById(tid).isEmpty()) {
                        System.out.println("This Trainer is not yet appointed to any course.");
                    } else {
                        System.out.println("\nHere is the list all the Assignments per student for each of your courses.");

                        for (Course c : tpcDao.getCoursesPerTrainerById(tid)) {
                            System.out.println("\n"+c);
                            if (spcDao.getStudentsPerCourseById(c.getId()).isEmpty()) {
                                System.out.println("This course has no Students enrolled yet.");
                            } else {
                                for (Student s : spcDao.getStudentsPerCourseById(c.getId())) {
                                    System.out.println(s.getFname()+" "+s.getLname()+"\n");
                                    if (apsDao.getListOfAssignmentsPerStudentId2(s.getId()).isEmpty()) {
                                        System.out.println("This course has no Assignments appointed yet.");
                                    } else {
                                        System.out.println("Assignments:");
                                        for (AssignmentsPerStudent a : apsDao.getListOfAssignmentsPerStudentId(s.getId())) {
                                            System.out.println(a.getAssignment().getTitle()+", \t"+a.getAssignment().getDescr()+", \tsubmit by = "+a.getAssignment().getDate()+", \tMark = "+a.getMark());
                                        }
                                    }
                                }
                            }
                        }
                    }

                    break;

                case 4:
                    tpcDao = new TrainersPerCourseDao();
                    spcDao = new StudentPerCourseDao();
                    apsDao = new AssignmentsPerStudentDao();

                    
                    if (tpcDao.getCoursesPerTrainerById(tid).isEmpty()) {
                            System.out.println("You don't have appointed to any courses yet.");
                        } else {
                    
                    do {
                                  
                        cDao = new CourseDao();
                        clist = new ArrayList<Course>();

                        clist = tpcDao.getCoursesPerTrainerById(tid);
                        
                            System.out.println("\nPlease select the course you want to mark the assignments for.");
                            
                            i = 1;
                            for (Course c : clist) {
                                System.out.println("[" + i + "]: " + c.getTitle()+" "+c.getStream()+" "+c.getType());
                                i++;
                            }

                            System.out.print("Enter your option here: ");
                            idx = getInput(input);

                            while (idx > clist.size() || idx < 0) {
                                System.out.print("\nPlease select a valid number: ");
                                idx = getInput(input);
                            }
                            cid = clist.get(idx - 1).getId();
                            
                            if (spcDao.getStudentsPerCourseById(cid).isEmpty()){
                                    System.out.println("This course has no Students enrolled yet.");
                                } else {
                            do {
                                spcDao = new StudentPerCourseDao();
                                ArrayList<Student> slist = new ArrayList<Student>();

                                slist = spcDao.getStudentsPerCourseById(cid);
                                
                                System.out.println("\nPlease select the student you want to mark the assignments for.");

                                i = 1;
                                for (Student s : slist) {
                                    System.out.println("[" + i + "]: " + s.getFname()+" "+s.getLname()+"\n");
                                    i++;
                                }

                                System.out.print("Enter your option here: ");
                                idx = getInput(input);

                                while (idx > slist.size() || idx < 0) {
                                    System.out.print("\nPlease select a valid number: ");
                                    idx = getInput(input);
                                }
                                sid = slist.get(idx - 1).getId();


                                if(apsDao.getListOfAssignmentsPerStudentId(sid).isEmpty()){
                                    System.out.println("This course has no Assignments appointed yet.");
                                } else {
                                do {
                                    System.out.println("\nPlease select the Assignment you want to mark.");

                                    aDao = new AssignmentDao();
                                    apsDao = new AssignmentsPerStudentDao();

                                    ArrayList<AssignmentsPerStudent> apslist = new ArrayList<AssignmentsPerStudent>();

                                    apslist = apsDao.getListOfAssignmentsPerStudentId(sid);
                                    i = 1;
                                    for (AssignmentsPerStudent aps : apslist) {
                                        System.out.println("[" + i + "]: " + aps.getAssignment().getTitle() + ", \t" + aps.getAssignment().getDescr() + ", \tsubmission date:" + aps.getAssignment().getDate() + ", \tMark: " + aps.getMark());
                                        i++;
                                    }

                                    System.out.print("Enter your option here: ");
                                    idx = getInput(input);

                                    while (idx > apslist.size() || idx < 0) {
                                        System.out.print("\nPlease select a valid number: ");
                                        idx = getInput(input);
                                    }
                                    //apsid = apslist.get(idx - 1).getId();
                                    aid = apslist.get(idx - 1).getAssignment().getId();

                                    System.out.println(cDao.getCourseById(cid).getTitle()+", "+cDao.getCourseById(cid).getStream()+", "+cDao.getCourseById(cid).getType());
                                    System.out.println(sDao.getStudentById(sid).getFname()+" "+sDao.getStudentById(sid).getLname());
                                    System.out.println(aDao.getAssignmentById(aid).getTitle()+", "+aDao.getAssignmentById(aid).getDescr());
                                    System.out.print("\nPlease enter your mark [0-100]: ");

                                    int m = getInput(input);
                                    while (m > 100 || m < 0) {
                                        System.out.print("\nPlease select a valid number between 1 and 100: ");
                                        m = getInput(input);
                                    }

                                    System.out.print("Do you want to proceed? [y]or[n]: ");
                                    if ((!(input.next()).equals("n"))) {
                                        apsDao.updateMarkAssignmentPerStudentById(sid, aid, tid, m);
                                    } else {
                                        System.out.println("Mark was canceled.\n");
                                    }

                                    System.out.print("Do you want to mark another assignment of the same student? [y] or [n]: ");
                                } while ((!(input.next()).toLowerCase().equals("n")));
                                }
                                System.out.print("Do you want to mark another student of the same course? [y] or [n]: ");
                            } while ((!(input.next()).toLowerCase().equals("n")));
                            }
                        System.out.print("Do you want to start over? [y] or [n]: ");
                    } while ((!(input.next()).toLowerCase().equals("n")));
                    }
                    break;

            }

            System.out.print("Do you want to go back to the Main Menu? [y] or [n]: ");
        } while ((!(input.next()).toLowerCase().equals("n")));
    }

    private void headMasterMenu() {
        System.out.println("\nWelcome!\n");
        do{
            System.out.println("\n-----HEADMASTER MENU-----\n");
        System.out.println("Please insert a number for one of the following options.");
        System.out.println("[1]: View, edit, add or delete the Courses of the school.");
        System.out.println("[2]: View, edit, add or delete the Students of the school.");
        System.out.println("[3]: View, edit, add or delete the Assignments of the school.");
        System.out.println("[4]: View, edit, add or delete the Trainers of the school.");
        System.out.println("[5]: View, edit, add or delete the Students per Course of the school.");
        System.out.println("[6]: View, edit, add or delete the Trainers per Course of the school.");
        System.out.println("[7]: View, edit, add or delete the Assignments per Course of the school.");
        System.out.println("[8]: View and edit Schedule per Course of the school.");
        
        System.out.print("Enter your option here: ");
        
        int option = getInput(input);
        while (!(option > 0 && option < 9)) {
            System.out.print("\nPlease select a number between [1] and [8]: ");
            option = getInput(input);
        }

        switch (option) {

            case 1: //[1]: View, edit, add or delete the courses of the school.
               do{
                   System.out.println("\n-----COURSE MENU-----\n");
                System.out.println("Please insert a number for one of the following options.");
                System.out.println("[1]: View the courses of the school.");
                System.out.println("[2]: Edit the courses of the school.");
                System.out.println("[3]: Add courses to the school.");
                System.out.println("[4]: Delete courses of the school.");
                System.out.print("Enter your option here: ");

                int option1 = getInput(input);
                while (!(option1 == 1 || option1 == 2 || option1 == 3 || option1 == 4)) {
                    System.out.print("\nPlease select a number between [1],[2],[3],[4]: ");
                    option1 = getInput(input);
                }

                courseCrud(option1);
                
                    System.out.print("Do you want to go back to the Course Menu? [y] or [n]: ");
                 } while ((!(input.next()).toLowerCase().equals("n")));
                break;

            case 2:
                do{
                    System.out.println("\n-----STUDENT MENU-----\n");
                System.out.println("Please insert a number for one of the following options.");
                System.out.println("[1]: View the all the students of the school.");
                System.out.println("[2]: Edit the students of the school.");
                System.out.println("[3]: Add students to the school.");
                System.out.println("[4]: Delete students from the school.");
                System.out.print("Enter your option here: ");

                int option2 = getInput(input);
                while (!(option2 == 1 || option2 == 2 || option2 == 3 || option2 == 4)) {
                    System.out.print("\nPlease select a number between [1],[2],[3],[4]: ");
                    option2 = getInput(input);
                }
                    
                studentCrud(option2);
                    
                    
                System.out.print("Do you want to go back to the Student Menu? [y] or [n]: ");
                 } while ((!(input.next()).toLowerCase().equals("n")));
                
                break;

            case 3:
                do{
                     System.out.println("\n-----ASSIGNMENT MENU-----\n");
                System.out.println("Please insert a number for one of the following options.");
                System.out.println("[1]: View the all the assignments of the school.");
                System.out.println("[2]: Edit the assignments of the school.");
                System.out.println("[3]: Add assignments to the school.");
                System.out.println("[4]: Delete assignments from the school.");
                System.out.print("Enter your option here: ");
                
                int option3 = getInput(input);
                while (!(option3 == 1 || option3 == 2 || option3 == 3 || option3 == 4)) {
                    System.out.print("\nPlease select a number between [1],[2],[3],[4]: ");
                    option3 = getInput(input);
                }
                    
                assignmentCrud(option3);
                
                
                    
                System.out.print("Do you want to go back to the Assignment Menu? [y] or [n]: ");
                } while ((!(input.next()).toLowerCase().equals("n")));
                break;

            case 4:
                  do{
                     System.out.println("\n-----TRAINERS MENU-----\n");
                System.out.println("Please insert a number for one of the following options.");
                System.out.println("[1]: View the all the trainers of the school.");
                System.out.println("[2]: Edit the trainers of the school.");
                System.out.println("[3]: Add trainers to the school.");
                System.out.println("[4]: Delete trainers from the school.");
                System.out.print("Enter your option here: ");
                
                int option4 = getInput(input);
                while (!(option4 == 1 || option4 == 2 || option4 == 3 || option4 == 4)) {
                    System.out.print("\nPlease select a number between [1],[2],[3],[4]: ");
                    option4 = getInput(input);
                }
                    
                trainerCrud(option4);
                
                
                    
                System.out.print("Do you want to go back to the Trainers Menu? [y] or [n]: ");
                } while ((!(input.next()).toLowerCase().equals("n")));
                
                break;

            case 5:
                do{
                 System.out.println("\n-----STUDENTS PER COURSE MENU-----\n");
                System.out.println("Please insert a number for one of the following options.");
                System.out.println("[1]: View the all the Students Per Course of the school.");
                System.out.println("[2]: Edit a Student's Course. ");
                System.out.println("[3]: Add a Student to a Course.");
                System.out.println("[4]: Delete Students from a Course.");
                System.out.print("Enter your option here: ");
                
                int option5 = getInput(input);
                while (!(option5 == 1 || option5 == 2 || option5 == 3 || option5 == 4)) {
                    System.out.print("\nPlease select a number between [1],[2],[3],[4]: ");
                    option5 = getInput(input);
                }
                
                studentPerCourseCrud(option5);
                
                System.out.print("Do you want to go back to the Students Per Course Menu? [y] or [n]: ");
                } while ((!(input.next()).toLowerCase().equals("n")));
                break;

            case 6:
                  do{
                 System.out.println("\n-----TRAINERS PER COURSE MENU-----\n");
                System.out.println("Please insert a number for one of the following options.");
                System.out.println("[1]: View the all the Trainers Per Course of the school.");
                System.out.println("[2]: Edit a Trainer's Course. ");
                System.out.println("[3]: Add a Trainer to a Course.");
                System.out.println("[4]: Delete Trainers from a Course.");
                System.out.print("Enter your option here: ");
                
                int option6 = getInput(input);
                while (!(option6 == 1 || option6 == 2 || option6 == 3 || option6 == 4)) {
                    System.out.print("\nPlease select a number between [1],[2],[3],[4]: ");
                    option6 = getInput(input);
                }
                
                trainerPerCourseCrud(option6);
                
                System.out.print("Do you want to go back to the Trainers Per Course Menu? [y] or [n]: ");
                } while ((!(input.next()).toLowerCase().equals("n")));
                break;

            case 7:
                do{
                 System.out.println("\n-----ASSIGNMENTS PER COURSE MENU-----\n");
                System.out.println("Please insert a number for one of the following options.");
                System.out.println("[1]: View the all the Assignments Per Course of the school.");
                System.out.println("[2]: Edit an Assignment's Course. ");
                System.out.println("[3]: Add an Assignment to a Course.");
                System.out.println("[4]: Delete Assignments from a Course.");
                System.out.print("Enter your option here: ");
                
                int option7 = getInput(input);
                while (!(option7 == 1 || option7 == 2 || option7 == 3 || option7 == 4)) {
                    System.out.print("\nPlease select a number between [1],[2],[3],[4]: ");
                    option7 = getInput(input);
                }
                
                assignmentsPerCourseCrud(option7);
                
                System.out.print("Do you want to go back to the Assignments Per Course Menu? [y] or [n]: ");
                } while ((!(input.next()).toLowerCase().equals("n")));
                break;

            case 8:
            do{System.out.println("\n-----SCHEDULE PER COURSE MENU-----\n");
                System.out.println("Please insert a number for one of the following options.");
                System.out.println("[1]: View the Schedule for the Courses of the school.");
                System.out.println("[2]: Edit the Schedule for the Courses of the school.");
                System.out.print("Enter your option here: ");
                
                int option8 = getInput(input);
                while (!(option8 == 1 || option8 == 2 || option8 == 3 || option8 == 4)) {
                    System.out.print("\nPlease select a number between [1],[2],[3],[4]: ");
                    option8 = getInput(input);
                }
                
                scheduleCrud(option8);
                
                
                
            System.out.print("Do you want to go back to the Schedule Per Course Menu? [y] or [n]: ");
                } while ((!(input.next()).toLowerCase().equals("n")));
                break;

        }
        System.out.print("Do you want to go back to the Headmaster Menu? [y] or [n]: ");
        } while ((!(input.next()).toLowerCase().equals("n")));
    }

    private void courseCrud(int opt) {
        CourseDao cDao = new CourseDao();
        ArrayList<Course> clist = new ArrayList<Course>();

        int cid;
        String cTitle;
        String cStream;
        String cType;
        String cStartDate;
        String cEndDate;
        int i;
        int idx;
        
        switch (opt) {

            case 1: //[1]: View the courses of the school.
                
                cDao = new CourseDao();
                clist = new ArrayList<Course>();
                
                clist = cDao.getListOfCourses();
                if (clist.isEmpty()){
                    System.out.println("There are no Courses. You need to add new Courses first.");
                } else {
                System.out.println("\nHere is a list of all the courses of the school:");
                for (Course c : clist) {
                    System.out.println(c);

                }
                }
                break;

            case 2: //[2]: Edit the courses of the school.
                if (cDao.getListOfCourses().isEmpty()){
                    System.out.println("There are no Courses. You need to add new Courses first.");
                } else {
                do{
                

                cDao = new CourseDao();
                clist = new ArrayList<Course>();
                
                clist = cDao.getListOfCourses();

                System.out.println("\nPlease select the course you want to edit.");
                i=1;
                for (Course c : clist) {
                    System.out.println("["+i+"]: "+c);
                    i++;
                }
                
                System.out.print("Enter your option here: ");
                    idx = getInput(input);
                    
                    while (idx > clist.size() || idx < 0) {
                        System.out.print("\nPlease select a valid number: ");
                        idx = getInput(input);
                    }
                    cid = clist.get(idx-1).getId(); 
                    
                        System.out.println("\nHere is the course you selected for update.");
                        System.out.println(cDao.getCourseById(cid));
                        
                        System.out.print("Do you want to edit the title of the course? [y] or [n]: ");
                        if ((!(input.next()).equals("n"))){
                            System.out.print("Insert a new title for the course: ");
                            cTitle = input.next();
                            while(cTitle.length()<3){
                                System.out.print("Input should be at least 3 characters long: ");
                                cTitle = input.next();
                            }
                        } else cTitle = cDao.getCourseById(cid).getTitle();
                       
                        System.out.print("Do you want to edit the Stream of the course? [y] or [n]: ");
                        if ((!(input.next()).equals("n"))){
                            System.out.print("Insert a new Stream for the course(Java or C#): ");
                            cStream = input.next();
                             while(cStream.length()<2){
                                System.out.print("Input should be at least 2 characters long: ");
                                cStream = input.next();
                            }
                        } else cStream = cDao.getCourseById(cid).getStream();
                        
                        System.out.print("Do you want to edit the Type of the course? [y] or [n]: ");
                        if ((!(input.next()).equals("n"))){
                            System.out.print("Insert a Type for the course(): Full-Time or Part-Time? ");
                            cType = input.next();
                             while(cType.length()<3){
                                System.out.print("Input should be at least 3 characters long: ");
                                cType = input.next();
                            }
                        } else cType = cDao.getCourseById(cid).getType();

                        System.out.print("Do you want to edit the Start Date of the course? [y] or [n]: ");
                        if ((!(input.next()).equals("n"))){
                            System.out.print("Insert a new Start Date for the course(yyyy-MM-dd): ");
                            cStartDate = input.next();
                            while (!(isInDateFormat(cStartDate))){
                                 cStartDate = input.next();
                            }
                        } else cStartDate = cDao.getCourseById(cid).getStartDate();
                        
                        System.out.print("Do you want to edit the End Date of the course? [y] or [n]: ");
                        if ((!(input.next()).equals("n"))){
                            System.out.print("Insert a new End Date for the course(yyyy-MM-dd): ");
                            cEndDate = input.next();
                            while (!(isInDateFormat(cEndDate))){
                                 cEndDate = input.next();
                            }
                        } else cEndDate = cDao.getCourseById(cid).getEndDate();
                        
                        cDao.updateCourseById(cid, cTitle, cStream, cType, cStartDate, cEndDate);
                        
                        System.out.println("\nHere is the edited course:");
                        System.out.println(cDao.getCourseById(cid));
                        
                        System.out.print("\nDo you want to edit another course? [y] or [n]: ");
        } while ((!(input.next()).toLowerCase().equals("n")));
                }
                 break;

            case 3: //[3]: Add courses to the school.
                    do{
                    cTitle = "";
                    cStream = "";
                    cType = "";
                    cStartDate = "";
                    cEndDate = "";
                    cDao = new CourseDao();
                    
                     System.out.println("\nInsert a new course.");
                     
                     System.out.print("Insert a title for the course: ");
                            cTitle = input.next();
                            while(cTitle.length()<3){
                                System.out.print("Input should be at least 3 characters long: ");
                                cTitle = input.next();
                            }
                     System.out.print("Insert a new Stream for the course(etc.Java, C#?): ");
                            cStream = input.next();
                            while(cStream.length()<2){
                                System.out.print("Input should be at least 2 characters long: ");
                                cStream = input.next();
                            }
                    System.out.print("Insert a Type for the course(etc.Full-Time, Part-Time): ");
                            cType = input.next(); 
                            while(cType.length()<3){
                                System.out.print("Input should be at least 3 characters long: ");
                                cType = input.next();
                            }
                    System.out.print("Insert a new Start Date for the course(yyyy-MM-dd): ");
                            cStartDate = input.next();
                            while (!(isInDateFormat(cStartDate))){
                                 cStartDate = input.next();
                            }
                    System.out.print("Insert a new End Date for the course(yyyy-MM-dd): ");
                            cEndDate = input.next();
                            while (!(isInDateFormat(cEndDate))){
                                 cEndDate = input.next();
                            }
                    cDao.insertCourse(cTitle, cStream, cType, cStartDate, cEndDate);
                            System.out.print("Do you want to add another course? [y]or[n]: ");
        } while ((!(input.next()).toLowerCase().equals("n")));
                break;

            case 4: //[4]: Delete courses of the school.
                
                do{  
                    if (cDao.getListOfCourses().isEmpty()){
                    System.out.println("There are no Courses to delete.");
                } else {
                System.out.println("\nPlease select the course you want to delete.");

                cDao = new CourseDao();
                clist = new ArrayList<Course>();
                
                clist = cDao.getListOfCourses();
                i=1;
                for (Course c : clist) {
                    System.out.println("["+i+"]: "+c);
                    i++;
                }
                
                System.out.print("Enter your option here: ");
                    idx = getInput(input);
                    
                    while (idx > clist.size() || idx < 0) {
                        System.out.print("\nPlease select a valid number: ");
                        idx = getInput(input);
                    }
                    cid = clist.get(idx-1).getId(); 
                    
                        System.out.println("\nHere is the course you selected to delete.");
                        System.out.println(cDao.getCourseById(cid));
                        System.out.print("Do you want to proceed? [y]or[n]: ");
                        if ((!(input.next()).toLowerCase().equals("n"))){
                        cDao.deleteCourseById(cid);
                        } else System.out.println("Deletion canceled.");
                    }
                         System.out.print("Do you want to delete another course? [y]or[n]: ");
                        } while ((!(input.next()).toLowerCase().equals("n")));
                break;

        }

    }
    
    
    private void studentCrud(int opt){
        StudentDao sDao = new StudentDao();
        ArrayList<Student> slist = new ArrayList<Student>();
        int sid;
        String sFname;
        String sLname;
        String sDob;
        int sFees;
        String sPass;
        String sUser;
         int i;
        int idx;
        
         switch (opt) {

             case 1: //[1]: View the students of the school.

                 sDao = new StudentDao();
                 slist = new ArrayList<Student>();

                 slist = sDao.getListOfStudents();
                 if (slist.isEmpty()) {
                     System.out.println("There are no students enrolled to the school.\nPlease add new students first.");
                 } else {
                     System.out.println("\nHere is a list of all the students of the school:");
                     for (Student s : slist) {
                         System.out.println(s);
                     }
                 }
                 break;
                
            case 2: // Edit the students of the school.
                if (sDao.getListOfStudents().isEmpty()){
                 System.out.println("There are no students enrolled to the school.\nPlease add new students first.");
                 } else {
                do{
                    System.out.println("\nPlease select the student you want to edit.");
                    sDao = new StudentDao();
                    slist = new ArrayList<Student>();
                    slist = sDao.getListOfStudents();
                    i = 1;
                    for (Student s : slist) {
                    System.out.println("["+i+"]: "+s);
                    i++;
                }
                    System.out.print("Enter your option here: ");
                    idx = getInput(input);
                    while (idx > slist.size() || idx < 0) {
                        System.out.print("\nPlease select a valid number: ");
                        idx = getInput(input);
                    }
                    sid = slist.get(idx-1).getId();
                
                    System.out.println("\nHere is the student you selected to edit.");
                    System.out.println(sDao.getStudentById(sid));
                    
                    String tempUser =  sDao.getStudentById(sid).getFname().substring(0, 1)+"."+sDao.getStudentById(sid).getLname();
                    
                    System.out.print("Do you want to change the first name of the student? [y] or [n]: ");
                        if ((!(input.next()).equals("n"))){
                            System.out.print("Insert a new first name for the student: ");
                            sFname = input.next();
                            while(sFname.length()<3){
                                System.out.print("Input should be at least 3 characters long: ");
                                sFname = input.next();
                            }
                        } else sFname = sDao.getStudentById(sid).getFname();
                        
                    System.out.print("Do you want to change the last name of the student? [y] or [n]: ");
                        if ((!(input.next()).equals("n"))){
                            System.out.print("Insert a new last name for the student: ");
                            sLname = input.next();
                            while(sLname.length()<3){
                                System.out.print("Input should be at least 3 characters long: ");
                                sLname = input.next();
                            }
                        } else sLname = sDao.getStudentById(sid).getLname();    
                        
                    System.out.print("Do you want to change the date of birth of the student? [y] or [n]: ");
                        if ((!(input.next()).equals("n"))){
                            System.out.print("Insert a new date of birth for the student in(yyyy-MM-dd): ");
                            sDob = input.next();
                            while (!(isInDateFormat(sDob))){
                                 sDob = input.next();
                            }
                        } else sDob = sDao.getStudentById(sid).getBday();
                        
                     System.out.print("Do you want to change the fees of the student? [y] or [n]: ");
                        if ((!(input.next()).equals("n"))){
                            System.out.print("Insert a new value for fees for the student: ");
                            sFees = input.nextInt();
                            while (sFees<0 && sFees>3000){
                                System.out.println("Fees should be between 0-3000. ");
                                sFees= input.nextInt();
                            }
                        } else sFees = sDao.getStudentById(sid).getFees();
                        
                        sUser = sFname.substring(0, 1)+"."+sLname;
                        if (!(sUser.equals(tempUser))){
                            sUser = userNameGenerator(sFname, sLname);
                            System.out.println("\nUsername changed to: "+sUser);
                        }
                        
                    sDao.updateStudentById(sid, sFname, sLname, sDob, sUser, sFees);
                    
                    System.out.println("\nHere is the edited student:");
                    System.out.println(sDao.getStudentById(sid));
                        
                System.out.print("Do you want to edit another student? [y] or [n]: ");
        } while ((!(input.next()).toLowerCase().equals("n")));
                }
                break;
            case 3: // Add students to school.
                
                do {
                    sFname = "";
                    sLname = "";
                    sDob = "";
                    sFees = 0;
                    sPass = "";
                    sUser = "";
                    sDao = new StudentDao();
                    
                    System.out.println("\nInsert a new student.");
                     
                     System.out.print("Insert a first name for the student: ");
                            sFname = input.next().trim();
                            while(sFname.length()<3){
                                System.out.print("Input should be at least 3 characters long: ");
                                sFname = input.next();
                            }
                     System.out.print("Insert a last name for the student: ");
                            sLname = input.next().trim();
                            while(sLname.length()<3){
                                System.out.print("Input should be at least 3 characters long: ");
                                sLname = input.next();
                            }
                    System.out.print("Insert a date of birth for the student in (yyyy-MM-dd): ");
                            sDob = input.next().trim();
                            while (!(isInDateFormat(sDob))){
                                 sDob = input.next();
                            }
                    System.out.print("Insert the fees for the student: ");
                            sFees= input.nextInt();
                            while (sFees<0 && sFees>3000){
                                System.out.println("Fees should be between 0-3000. ");
                                sFees= input.nextInt();
                            }
                            
                            sUser = userNameGenerator(sFname, sLname);
                    System.out.println("\nThis username was automatically generated: "+sUser);
                    System.out.println("\n--- Password rules --- \nAll passwords should:"
                            + "\n- be 5 to 10 characters long"
                            + "\n- contain at least one lower case letter"
                            + "\n- contain at least one upper case letter"
                            +"\n- contain at least one special character and one digit.");
                    do{
                    System.out.print("\nPlease enter a valid password: ");
                               sPass = input.next();
                    } while (!passwordValidationOk(sPass));
         
                    System.out.println("Success!\nStudent's password: "+sPass);
                    
                    sPass = hashingPassword(sPass);
                    sDao.insertStudent(sFname, sLname, sDob, sFees,sUser,sPass);
                   
                    System.out.println("New student succesfully added.");
                    
                    System.out.print("Do you want to add another student? [y]or[n]: ");
                } while ((!(input.next()).toLowerCase().equals("n")));
                break;
            case 4: // Delete student from the school.
                do{
                   if(sDao.getListOfStudents().isEmpty()){
                       System.out.println("There are no more students to the school.\nPlease add new students.");
                   }else{
                   System.out.print("\nPlease select the student you want to delete.");
                   sDao = new StudentDao();
                    slist = new ArrayList<Student>();
                    slist = sDao.getListOfStudents();
                    i = 1;
                    for (Student s : slist) {
                    System.out.println("["+i+"]: "+s);
                    i++;
                }
                    System.out.print("Enter your option here: ");
                    idx = getInput(input);
                    while (idx > slist.size() || idx < 0) {
                        System.out.print("\nPlease select a valid number: ");
                        idx = getInput(input);
                    }
                    sid = slist.get(idx-1).getId();
                
                    System.out.println("\nHere is the student you want to delete.");
                    System.out.println(sDao.getStudentById(sid));
                    System.out.print("Do you want to proceed? [y] or [n]: ");
                        if ((!(input.next()).equals("n"))){
                      sDao.deleteStudentById(sid);
                        } else System.out.println("Deletion canceled.");
                   
                   }
                   System.out.print("Do you want to delete another student? [y] or [n]: ");
                   } while ((!(input.next()).toLowerCase().equals("n")));
                break;
         }
    }
    
    
    private void assignmentCrud(int opt){
        AssignmentDao aDao = new AssignmentDao();
        ArrayList<Assignment> alist = new ArrayList<Assignment>();
        int aid;
        String aTitle;
        String aDescr;
        String aSubmissionDate;
        int aMark;
        int i;
        int idx;
        
        switch (opt) {

            case 1: // View all the assignments

                aDao = new AssignmentDao();
                alist = new ArrayList<Assignment>();
                alist = aDao.getListOfAssignments();
                if (alist.isEmpty()) {
                    System.out.println("There are no assignments!");
                } else {
                    System.out.println("\nHere is a list of all the assignments of the school:");
                    for (Assignment a : alist) {
                        System.out.println(a);
                    }
                }
                break;

            case 2: // Edit the assignments
            if (aDao.getListOfAssignments().isEmpty()){
            System.out.println("There are no assignments!");
                } else {
                do{
                    System.out.println("Please select the assignment you want to edit.");
                    aDao = new AssignmentDao();
                    alist = new ArrayList<Assignment>();
                    alist = aDao.getListOfAssignments();
                    i=1;
                    for (Assignment a : alist) {
                    System.out.println("["+i+"]: "+a);
                    i++;
                }
                    
                     System.out.print("Enter your option here: ");
                    idx = getInput(input);
                    
                    while (idx > alist.size() || idx < 0) {
                        System.out.print("\nPlease select a valid number: ");
                        idx = getInput(input);
                    }
                    aid = alist.get(idx-1).getId();
                    
                     
                     System.out.println("Here is the assignment you selected to edit:");
                    System.out.println(aDao.getAssignmentById(aid));
                    
                    
                     System.out.print("Do you want to change the title of the assignemnt? [y] or [n]: ");
                        if ((!(input.next()).equals("n"))){
                            System.out.print("Insert a new title for the assignment(one word): ");
                            aTitle = input.next();
                            while(aTitle.length()<3){
                                System.out.print("Input should be one word with no spaces and at least 3 characters long: ");
                                aTitle = input.next();
                            }
                        } else aTitle = aDao.getAssignmentById(aid).getTitle();
                        
                    System.out.print("Do you want to change the description of the assignment? [y] or [n]: ");
                        if ((!(input.next()).equals("n"))){
                            System.out.print("Insert a new decription for the assignment(one word): ");
                            aDescr = input.next();
                            while(aDescr.length()<3){
                                System.out.print("Input should be one word with no spaces and at least 3 characters long: ");
                                aDescr = input.next();
                            }
                        } else aDescr = aDao.getAssignmentById(aid).getDescr();    
                        
                    System.out.print("Do you want to change the submission date of the assignment? [y] or [n]: ");
                        if ((!(input.next()).equals("n"))){
                            System.out.print("Insert a new submission date in(yyyy-MM-dd): ");
                            aSubmissionDate = input.next();
                            while (!(isInDateFormat(aSubmissionDate))){
                                 aSubmissionDate = input.next();
                            }
                        } else aSubmissionDate = aDao.getAssignmentById(aid).getDate();
                        
                     System.out.print("Do you want to change the total mark of the assignment? [y] or [n]: ");
                        if ((!(input.next()).equals("n"))){
                            System.out.print("Insert a new total mark 0-100: ");
                            aMark = input.nextInt();
                            while (aMark<0 && aMark>100){
                                System.out.print("Value should be 0-100: ");
                                aMark = input.nextInt();
                            }
                            
                        } else aMark = aDao.getAssignmentById(aid).getMark();
                        
                    aDao.updateAssignmentById(aid, aTitle, aDescr, aSubmissionDate, aMark);
                    
                    System.out.println("Here is the edited assignment.");
                    System.out.println(aDao.getAssignmentById(aid));
                    
                    
                System.out.print("Do you want to edit another assignment? [y] or [n]: ");
               } while ((!(input.next()).toLowerCase().equals("n")));
            }
                break;
                
            case 3: // Add new assignment
                
                do{
                    aTitle = "";
                    aDescr = "";
                    aSubmissionDate = "";
                    aMark = 0;
                    aDao = new AssignmentDao();
                    
                    System.out.println("Create a new Assignment.");
                 
                    System.out.print("Insert a title for the assignment(one word): ");
                        
                            aTitle = input.next();
                            while(aTitle.length()<3){
                                System.out.print("Input should be one word with no spaces and at least 3 characters long: ");
                                aTitle = input.next();
                            }
                     System.out.print("Insert a description for the assignment(one word): ");
                            aDescr = input.next();
                            while(aDescr.length()<3){
                                System.out.print("Input should be one word with no spaces and at least 3 characters long: ");
                                aDescr = input.next();
                            }
                    System.out.print("Insert a submission date for the assignment in (yyyy-MM-dd): ");
                            aSubmissionDate = input.next(); 
                             while (!(isInDateFormat(aSubmissionDate))){
                                 aSubmissionDate = input.next();
                            }
                    System.out.print("Insert the total mark for the assignment: ");
                            aMark= input.nextInt();
                    while (aMark<0 && aMark>100){
                                System.out.print("Value should be 0-100: ");
                                aMark = input.nextInt();
                            }
                    aDao.insertAssignment(aTitle, aDescr, aSubmissionDate, aMark);
                    
                System.out.print("Do you want to add another assignment? [y] or [n]: ");
                } while ((!(input.next()).toLowerCase().equals("n")));
                break;

            case 4: // Delete Assignment
               
                do{
                    if (aDao.getListOfAssignments().isEmpty()){
                        System.out.println("There are no more assignments.\nPlease add new Assignments.");
                    }else{
                    System.out.println("\nPlease select the assignment you want to delete.");
                    aDao = new AssignmentDao();
                    alist = new ArrayList<Assignment>();
                    alist = aDao.getListOfAssignments();
                    i=1;
                    for (Assignment a : alist) {
                    System.out.println("["+i+"]: "+a);
                    i++;
                }
                     
                     System.out.print("Enter your option here: ");
                    idx = getInput(input);
                    
                    while (idx > alist.size() || idx < 0) {
                        System.out.print("\nPlease select a valid number: ");
                        idx = getInput(input);
                    }
                    aid = alist.get(idx-1).getId(); 
                    
                     System.out.println("\nHere is the assignment you selected to delete.");
                    System.out.println(aDao.getAssignmentById(aid));
                    
                     System.out.print("Do you want to proceed? [y] or [n]: ");
                        if ((!(input.next()).equals("n"))){
                     aDao.deleteAssignmentById(aid);
                        } else System.out.println("Deletion canceled.");
                    }    
                    System.out.print("Do you want to delete another assignment? [y] or [n]: ");
                   } while ((!(input.next()).toLowerCase().equals("n")));
                
                break;
        
        }
    
    }
    
    
    private void trainerCrud(int opt){
        TrainerDao tDao = new TrainerDao();
        ArrayList<Trainer> tlist = new ArrayList<Trainer>();
        int tid;
        String tFname;
        String tLname;
        String tSubj;
        String tPass;
        String tUser;
        int i;
        int idx;
        
        switch (opt) {

            case 1: //View all the Trainers

                tDao = new TrainerDao();
                tlist = new ArrayList<Trainer>();
                tlist = tDao.getListOfTrainers();
                if (tlist.isEmpty()) {
                    System.out.println("There are no Trainers! \nAdd new Trainers.");
                } else {
                    System.out.println("\nHere is a list of all the trainers of the school:");
                    for (Trainer t : tlist) {
                        System.out.println(t);
                    }
                }
                break;
                
            case 2: // Edit the Trainers
               if (tDao.getListOfTrainers().isEmpty()){
                  System.out.println("There are no Trainers! \nAdd new Trainers.");
                } else {
                
                do{
                    System.out.println("\nPlease select the trainer you want to edit:");
                tDao = new TrainerDao();
                tlist = new ArrayList<Trainer>();
                tlist = tDao.getListOfTrainers();
                i = 1;
                for (Trainer t : tlist) {
                    System.out.println("["+i+"]: "+t);
                    i++;
                }
                
                System.out.print("Enter your option here: ");
                    idx = getInput(input);
                    
                    while (idx > tlist.size() || idx < 0) {
                        System.out.print("\nPlease select a valid number: ");
                        idx = getInput(input);
                    }
                    tid = tlist.get(idx-1).getId(); 
                 
                    System.out.println("Here is the trainer you selected to edit:");
                    System.out.println(tDao.getTrainerById(tid));
                    
                    String tempUser =  tDao.getTrainerById(tid).getFname().substring(0, 1)+"."+tDao.getTrainerById(tid).getLname();

                     System.out.print("Do you want to change the first name of the trainer? [y] or [n]: ");
                        if ((!(input.next()).equals("n"))){
                            System.out.print("Insert a new first name for the trainer: ");
                            tFname = input.next();
                            while(tFname.length()<3){
                                System.out.print("Input should be at least 3 characters long: ");
                                tFname = input.next();
                            }
                        } else tFname = tDao.getTrainerById(tid).getFname();

                      System.out.print("Do you want to change the last name of the trainer? [y] or [n]: ");
                        if ((!(input.next()).equals("n"))){
                            System.out.print("Insert a new last name for the trainer: ");
                            tLname = input.next();
                            while(tLname.length()<3){
                                System.out.print("Input should be at least 3 characters long: ");
                                tLname = input.next();
                            }
                        } else tLname = tDao.getTrainerById(tid).getLname();
                        
                        System.out.print("Do you want to change the subject of the trainer? [y] or [n]: ");
                        if ((!(input.next()).equals("n"))){
                            System.out.print("Insert a new subject for the trainer (ie Java, C#): ");
                            tSubj = input.next();
                            while(tSubj.length()<2){
                                System.out.print("Input should be at least 2 characters long: ");
                                tSubj = input.next();
                            }
                        } else tSubj = tDao.getTrainerById(tid).getSubj();
                        
                        
                         tUser = tFname.substring(0, 1)+"."+tLname;
                        if (!(tUser.equals(tempUser))){
                            tUser = userNameGenerator(tFname, tLname);
                            System.out.println("Username changed to: "+tUser);
                        }
                        
                        tDao.updateTrainerById(tid, tFname, tLname, tSubj,tUser);
                        
                        System.out.println("\nHere is the edited trainer:");
                         System.out.println(tDao.getTrainerById(tid));
                    
               System.out.print("Do you want to edit another trainer? [y]or[n]: ");
               } while ((!(input.next()).toLowerCase().equals("n")));
               }
                   break;
            case 3: // Add new Trainer
                
                do{
                tFname = "";
                tLname = "";
                tSubj = "";
                tPass = "";
                tUser = "";
                tDao = new TrainerDao();
                
                System.out.println("Insert a new Trainer.");
                    
                    System.out.print("Insert a first name for the Trainer: ");
                            tFname = input.next().trim();
                            while(tFname.length()<3){
                                System.out.print("Input should be at least 3 characters long: ");
                                tFname = input.next();
                            }
                    System.out.print("Insert a last name for the Trainer: ");
                            tLname = input.next().trim();
                            while(tLname.length()<3){
                                System.out.print("Input should be at least 3 characters long: ");
                                tLname = input.next();
                            }
                    System.out.print("Insert a subject for the Trainer(ie Java, C#): ");
                            tSubj = input.next().trim();
                            while(tSubj.length()<2){
                                System.out.print("Input should be at least 2 characters long: ");
                                tSubj = input.next();
                            }
                             tUser = userNameGenerator(tFname, tLname);
                    System.out.println("\n This username was automatically generated: "+tUser);
                    System.out.println("\n Password rules. \nAll passwords should:"
                            + "\n- be 5 to 10 characters long"
                            + "\n- contain at least one lower case letter"
                            + "\n - contain at least one upper case letter"
                            +"\n contain at least one special character and one digit.");
                    do{
                    System.out.print("\nPlease enter a valid password: ");
                               tPass = input.next();
                    } while (!passwordValidationOk(tPass));
         
                    System.out.print("Success!\nTrainer's password: "+tPass);
   
                    tPass = hashingPassword(tPass);
                    tDao.insertTrainer(tFname, tLname, tSubj, tUser, tPass);
                    System.out.println("New Trainer succesfully added.");
                         
                             
                System.out.print("Do you want to add another trainer? [y]or[n]: ");
                } while ((!(input.next()).toLowerCase().equals("n")));
                   break;
                   
            case 4: //Delete Trainer
                do{
                    if (tDao.getListOfTrainers().isEmpty()){
                          System.out.println("There are no Trainers! \nAdd new Trainers.");
                } else {
                    System.out.println("Please select the trainer you want to delete:");
                tDao = new TrainerDao();
                tlist = new ArrayList<Trainer>();
                tlist = tDao.getListOfTrainers();
                i = 1;
                for (Trainer t : tlist) {
                    System.out.println("["+i+"] "+t);
                    i++;
                }
                
                System.out.print("Enter your option here: ");
                    idx = getInput(input);
                    
                    while (idx > tlist.size() || idx < 0) {
                        System.out.print("\nPlease select a valid number: ");
                        idx = getInput(input);
                    }
                    tid = tlist.get(idx-1).getId(); 
                 
                    System.out.println("Here is the trainer you selected to delete:");
                    System.out.println(tDao.getTrainerById(tid));
                    
                    System.out.print("Do you want to proceed? [y]or[n]: ");
                        if ((!(input.next()).equals("n"))){
                     tDao.deleteTrainerById(tid);
                        } else System.out.println("Deletion canceled.");
                    }
                   System.out.print("Do you want to delete another trainer? [y]or[n]: ");
                   } while ((!(input.next()).toLowerCase().equals("n"))); 
                   break;       
                   
        }
    }

    
    private void studentPerCourseCrud(int opt){
        StudentPerCourseDao spcDao = new StudentPerCourseDao();
       
        CourseDao cDao = new CourseDao();
        ArrayList<Course> clist = new  ArrayList<Course>();
        ArrayList<Course> clist2 = new  ArrayList<Course>();
        StudentDao sDao = new StudentDao();
        ArrayList<Student> slist = new ArrayList<Student>();
        int cid2;
        int cid;
        int sid;
        int i;
        int idx;
        
        if ((cDao.getListOfCourses().isEmpty()) || (sDao.getListOfStudents().isEmpty())) {
            System.out.println("There are no Courses or Students!");
            opt = 5;
        }
        
        switch (opt) {

            case 1: // View
                System.out.println("\nHere is a list of all the Students Per Course.");
                clist = cDao.getListOfCourses();
               
                for (Course c : clist) {
                    System.out.println("\n"+c);
                    for(Student s: (spcDao.getStudentsPerCourseById(c.getId()))){
                        System.out.println(s);
                    }
                }
                       
                
                break;
                
                
                case 2: // Edit
                    do{
                    System.out.println("\nPlease select the student you want to change its course.");
                    sDao = new StudentDao();
                    spcDao = new StudentPerCourseDao();
                    slist = new ArrayList<Student>();
                    slist = sDao.getListOfStudents();
                        i = 1;
                        for (Student s : slist) {
                        System.out.println("["+i+"]: "+s);
                        i++;
                        }
                    System.out.print("Enter your option here: ");
                    idx = getInput(input);
                    while (idx > slist.size() || idx < 0) {
                        System.out.print("\nPlease select a valid number: ");
                        idx = getInput(input);
                    }
                    sid = slist.get(idx-1).getId();
                
                    System.out.println("\nPlease select the course the student is attending that you want to change:");
                    

                cDao = new CourseDao();
                clist = new ArrayList<Course>();
                clist = spcDao.getCoursesperStudentById(sid);
                
                if(clist.isEmpty()){
                    System.out.println("The student doesn't attend any course.\nEnroll student to a Course.");
                } else {
                
                i=1;
                for (Course c : clist) {
                    System.out.println("["+i+"]: "+c);
                    i++;
                }
                
                System.out.print("Enter your option here: ");
                    idx = getInput(input);
                    
                    while (idx > clist.size() || idx < 0) {
                        System.out.print("\nPlease select a valid number: ");
                        idx = getInput(input);
                    }
                    cid = clist.get(idx-1).getId(); 
                    
                    cid2 = spcDao.getIdForStudentsPerCourse(cid, sid);
                    
                                    System.out.println("\nFinally, select the course you want to assign to the student.");

                                    cDao = new CourseDao();
                                    clist2 = new ArrayList<Course>();

                                    clist2 = cDao.getListOfCourses();
                                    // exclude the other courses he is already attending
                                   clist2 = intersectCourses(clist, clist2);
                                    
                               if (clist2.size()<1){
                                   System.out.println("There are no more courses to attend.");
                               }  else {
                                    i=1;
                                    for (Course c : clist2) {
                                        System.out.println("["+i+"]: "+c);
                                        i++;
                                    }

                                    System.out.print("Enter your option here: ");
                                        idx = getInput(input);

                                        while (idx > clist2.size() || idx < 0) {
                                            System.out.print("\nPlease select a valid number: ");
                                            idx = getInput(input);
                                        }
                                        cid = clist2.get(idx-1).getId(); 
                                        
                                        
                                        
                    
                  spcDao.updateStudentPerCourseById(cid2, sid, cid);
                               }
                }
                    System.out.print("Do you want to change another Student per course? [y]or[n]: ");
                   } while ((!(input.next()).toLowerCase().equals("n"))); 
                  
                    break;
                    
                    
                    case 3: // Insert
                        do{
                            System.out.println("\nPlease select the student you want to add to a course.");
                            sDao = new StudentDao();
                            spcDao = new StudentPerCourseDao();
                            slist = new ArrayList<Student>();
                            slist = sDao.getListOfStudents();
                            i = 1;
                            for (Student s : slist) {
                                System.out.println("[" + i + "]: " + s);
                                i++;
                            }
                            System.out.print("Enter your option here: ");
                            idx = getInput(input);
                            while (idx > slist.size() || idx < 0) {
                                System.out.print("\nPlease select a valid number: ");
                                idx = getInput(input);
                            }
                            sid = slist.get(idx - 1).getId();


                    
                     System.out.println("\nPlease select the course you want to assign to the student.");
                                    
                                    cDao = new CourseDao();
                                    clist = new ArrayList<Course>();

                                    clist = cDao.getListOfCourses();
                                    clist2 = spcDao.getCoursesperStudentById(sid);
                                    
                                    clist2 = intersectCourses(clist, clist2);
                                    
                                  if (clist2.size()<1){
                                   System.out.println("There are no more courses to attend.");
                               }  else {
                                    i=1;
                                    for (Course c : clist2) {
                                        System.out.println("["+i+"]: "+c);
                                        i++;
                                    }

                                    System.out.print("Enter your option here: ");
                                        idx = getInput(input);

                                        while (idx > clist2.size() || idx < 0) {
                                            System.out.print("\nPlease select a valid number: ");
                                            idx = getInput(input);
                                        }
                                        cid = clist2.get(idx-1).getId(); 
                                      
                                  spcDao.insertStudentPerCourse(sid, cid);
                                  }
                  System.out.print("\nDo you want to add another Student to a course? [y]or[n]: ");
                   } while ((!(input.next()).toLowerCase().equals("n"))); 
                        break;
                        
                        
                case 4: // Delete
                do {
                    
                    System.out.println("\nPlease select the student you want to delete from a course.");
                    sDao = new StudentDao();
                    spcDao = new StudentPerCourseDao();
                    slist = new ArrayList<Student>();
                    slist = sDao.getListOfStudents();
                    i = 1;
                    for (Student s : slist) {
                        System.out.println("[" + i + "]: " + s);
                        i++;
                    }
                    System.out.print("Enter your option here: ");
                    idx = getInput(input);
                    while (idx > slist.size() || idx < 0) {
                        System.out.print("\nPlease select a valid number: ");
                        idx = getInput(input);
                    }
                    sid = slist.get(idx - 1).getId();

                    System.out.println("Please select the course he/she is attending that you want to delete:");

                    cDao = new CourseDao();
                    clist = new ArrayList<Course>();

                    clist = spcDao.getCoursesperStudentById(sid);
                    if(clist.isEmpty()){
                        System.out.println("The student doesn't attend any courses. \nEnroll Student to a Course.");
                    } else {
                    
                    i = 1;
                    for (Course c : clist) {
                        System.out.println("[" + i + "]: " + c);
                        i++;
                    }

                    System.out.print("Enter your option here: ");
                    idx = getInput(input);

                    while (idx > clist.size() || idx < 0) {
                        System.out.print("\nPlease select a valid number: ");
                        idx = getInput(input);
                    }
                    cid = clist.get(idx - 1).getId();

                    System.out.print("Do you want to proceed? [y] or [n]: ");
                    if ((!(input.next()).equals("n"))) {
                        spcDao.deleteStudentFromCourseByIds(sid, cid);
                    } else {
                        System.out.println("Deletion canceled.");
                    }
                    }
                    System.out.print("\nDo you want to delete another Student from its course? [y] or [n]: ");
                } while ((!(input.next()).toLowerCase().equals("n")));
                break;
        
            case 5:
                break;
        }
    }
    
    
    private void trainerPerCourseCrud(int opt){
        
        TrainersPerCourseDao tpcDao = new TrainersPerCourseDao();
       CourseDao cDao = new CourseDao();
        ArrayList<Course> clist = new  ArrayList<Course>();
         ArrayList<Course> clist2 = new  ArrayList<Course>();
        TrainerDao tDao = new TrainerDao();
        ArrayList<Trainer> tlist = new ArrayList<Trainer>();
        int cid;
        int cid2;
        int tid;
        int i;
        int idx;
         
        if ((cDao.getListOfCourses().isEmpty()) || (tDao.getListOfTrainers().isEmpty())) {
            System.out.println("There are no Courses or Trainers!");
            opt = 5;
        }
        
        switch (opt) {

            case 1: // View
                System.out.println("\nHere is a list of all the Trainers Per Course.");
                clist = cDao.getListOfCourses();
               
                for (Course c : clist) {
                    System.out.println(c);
                    for(Trainer t: (tpcDao.getTrainersPerCourseById(c.getId()))){
                        System.out.println(t);
                    }
                }
                break;
                
            case 2: // Edit
                do{
                    System.out.println("\nPlease select the trainer you want to change its course.");
                    tDao = new TrainerDao();
                    tpcDao = new TrainersPerCourseDao();
                    tlist = new ArrayList<Trainer>();
                    tlist = tDao.getListOfTrainers();
                        i = 1;
                        for (Trainer t : tlist) {
                         System.out.println("["+i+"]: "+t);
                        i++;
                        }
                    System.out.print("Enter your option here: ");
                    idx = getInput(input);
                    while (idx > tlist.size() || idx < 0) {
                        System.out.print("\nPlease select a valid number: ");
                        idx = getInput(input);
                    }
                    tid = tlist.get(idx-1).getId();
                    
                 System.out.println("\nPlease select the course the trainer is teaching that you want to change:");
                    

                cDao = new CourseDao();
                clist = new ArrayList<Course>();
                
                clist = tpcDao.getCoursesPerTrainerById(tid);
                if (clist.isEmpty()){
                    System.out.println("The Trainer is not appointed to any course.");
                } else {
                i=1;
                for (Course c : clist) {
                    System.out.println("["+i+"]: "+c);
                    i++;
                }
                
                System.out.print("Enter your option here: ");
                    idx = getInput(input);
                    
                    while (idx > clist.size() || idx < 0) {
                        System.out.print("\nPlease select a valid number: ");
                        idx = getInput(input);
                    }
                cid = clist.get(idx-1).getId();         
                       
                cid2 = tpcDao.getIdForTrainersPerCourse(cid, tid);
                
                 System.out.println("\nFinally, select the course you want to assign to the trainer.");

                                    cDao = new CourseDao();
                                    clist2 = new ArrayList<Course>();

                                    clist2 = cDao.getListOfCourses();
                                    // exclude the other courses he is already teaching
                                   clist2 = intersectCourses(clist, clist2);
                    
                        if (clist2.size()<1){
                                   System.out.println("There are no more courses to attend.");
                               }  else {
                                    i=1;
                                    for (Course c : clist2) {
                                        System.out.println("["+i+"]: "+c);
                                        i++;
                                    }

                              System.out.print("Enter your option here: ");
                            idx = getInput(input);

                            while (idx > clist2.size() || idx < 0) {
                                System.out.print("\nPlease select a valid number: ");
                                idx = getInput(input);
                            }
                            cid = clist2.get(idx - 1).getId();
                        
                            
                            tpcDao.updateTrainerPerCourseById(cid2, tid, cid);
                        }
                }
                 System.out.print("Do you want to change another Trainer per course? [y] or [n]: ");
                   } while ((!(input.next()).toLowerCase().equals("n"))); 
                break;
            
            case 3: // Insert
                    do{
                    System.out.println("\nPlease select the trainer you want to add to a course.");
                    tDao = new TrainerDao();
                    tpcDao = new TrainersPerCourseDao();
                    tlist = new ArrayList<Trainer>();
                    tlist = tDao.getListOfTrainers();
                        i = 1;
                        for (Trainer t : tlist) {
                         System.out.println("["+i+"]: "+t);
                        i++;
                        }
                    System.out.print("Enter your option here: ");
                    idx = getInput(input);
                    while (idx > tlist.size() || idx < 0) {
                        System.out.print("\nPlease select a valid number: ");
                        idx = getInput(input);
                    }
                    tid = tlist.get(idx-1).getId();
                        
                     System.out.println("\nPlease select the new course you want to assign to the trainer.");
                                   
                                    cDao = new CourseDao();
                                    clist = new ArrayList<Course>();

                                    clist = cDao.getListOfCourses();
                                    clist2 = tpcDao.getCoursesPerTrainerById(tid);
                                    
                                    clist2 = intersectCourses(clist, clist2);
                                    
                                     if (clist2.size()<1){
                                   System.out.println("There are no more courses to be assigned.");
                               }  else {
                                    i=1;
                                    for (Course c : clist2) {
                                        System.out.println("["+i+"]: "+c);
                                        i++;
                                    }

                                    System.out.print("Enter your option here: ");
                                        idx = getInput(input);

                                        while (idx > clist2.size() || idx < 0) {
                                            System.out.print("\nPlease select a valid number: ");
                                            idx = getInput(input);
                                        }
                                        cid = clist2.get(idx-1).getId(); 
                                    
                        tpcDao.insertTrainerPerCourse(tid, cid);
                                     }
                     System.out.print("\nDo you want to add another Trainer to a course? [y] or [n]: ");
                   } while ((!(input.next()).toLowerCase().equals("n"))); 
                
                break;
                
            case 4: // Delete
                do{
                    System.out.println("\nPlease select the trainer you want to delete from a course.");
                    tDao = new TrainerDao();
                    tpcDao = new TrainersPerCourseDao();
                    tlist = new ArrayList<Trainer>();
                    tlist = tDao.getListOfTrainers();
                        i = 1;
                        for (Trainer t : tlist) {
                         System.out.println("["+i+"]: "+t);
                        i++;
                        }
                    System.out.print("Enter your option here: ");
                    idx = getInput(input);
                    while (idx > tlist.size() || idx < 0) {
                        System.out.print("\nPlease select a valid number: ");
                        idx = getInput(input);
                    }
                    tid = tlist.get(idx-1).getId();
                    
                   System.out.println("Please select the course he/she is teaching that you want to delete:");
                   

                cDao = new CourseDao();
                clist = new ArrayList<Course>();
                clist = tpcDao.getCoursesPerTrainerById(tid);
                     if(clist.isEmpty()){
                        System.out.println("The Trainer isn't appointed any courses. \nAppoint Trainer to a Course.");
                    } else {
                i=1;
                for (Course c : clist) {
                    System.out.println("["+i+"]: "+c);
                    i++;
                }
                
                System.out.print("Enter your option here: ");
                    idx = getInput(input);
                    
                    while (idx > clist.size() || idx < 0) {
                        System.out.print("\nPlease select a valid number: ");
                        idx = getInput(input);
                    }
                    cid = clist.get(idx-1).getId(); 
                    
                   
                     System.out.print("Do you want to proceed? [y] or [n]: ");
                        if ((!(input.next()).equals("n"))){
                            tpcDao.deleteTrainersFromCourseByIds(cid, tid);
                        } else System.out.println("Deletion canceled.");
                    
                     }
                    System.out.print("\nDo you want to delete another Student from its course? [y] or [n]: ");
                   } while ((!(input.next()).toLowerCase().equals("n"))); 
                break;
                
                case 5:
                break;

        }
    }
    
     private void assignmentsPerCourseCrud(int opt){
        AssignmentsPerCourseDao apcDao = new AssignmentsPerCourseDao();
        CourseDao cDao = new CourseDao();
        ArrayList<Course> clist = new  ArrayList<Course>();
        ArrayList<Course> clist2 = new  ArrayList<Course>();
        AssignmentDao aDao = new AssignmentDao();
        ArrayList<Assignment> alist = new ArrayList<Assignment>();
        
        int cid2;
        int cid;
        int aid;
        int i;
        int idx;
        
        if ((cDao.getListOfCourses().isEmpty()) || (aDao.getListOfAssignments().isEmpty())) {
            System.out.println("There are no Courses or Assignments!");
            opt = 5;
        }
         
         switch(opt){
             
             
             case 1: // View
                   System.out.println("\nHere is a list of all the Assignments Per Course.");
                clist = cDao.getListOfCourses();
               
                for (Course c : clist) {
                    System.out.println("\n"+c);
                    for(Assignment a: (apcDao.getAssignmentsPerCourseById(c.getId()))){
                        System.out.println(" "+a);
                    }
                }
                 break;
             
             case 2: // Edit
                 do{
                     System.out.println("Please select the Assignment you want to change the course.");
                     aDao = new AssignmentDao();
                     apcDao = new AssignmentsPerCourseDao();
                     alist = new ArrayList<Assignment>();
                     alist = aDao.getListOfAssignments();
                     
                          i = 1;
                        for (Assignment a : alist) {
                         System.out.println("["+i+"]: "+a);
                        i++;
                        }
                    System.out.print("Enter your option here: ");
                    idx = getInput(input);
                    while (idx > alist.size() || idx < 0) {
                        System.out.print("\nPlease select a valid number: ");
                        idx = getInput(input);
                    }
                    aid = alist.get(idx-1).getId();
                     
                   System.out.println("\nPlease select the course the Assignment is appointed that you want to change:");
                    

                cDao = new CourseDao();
                clist = new ArrayList<Course>();
                
                clist = apcDao.getCoursesPerAssignmentById(aid);
                     if (clist.isEmpty()){
                    System.out.println("The Assignment is not appointed to any course.");
                } else {
                      i=1;
                for (Course c : clist) {
                    System.out.println("["+i+"]: "+c);
                    i++;
                }
                
                System.out.print("Enter your option here: ");
                    idx = getInput(input);
                    
                    while (idx > clist.size() || idx < 0) {
                        System.out.print("\nPlease select a valid number: ");
                        idx = getInput(input);
                    }
                cid = clist.get(idx-1).getId();        
                
                cid2 = apcDao.getIdForAssignmentsPerCourse(cid, aid);
                     
                      System.out.println("\nFinally, select the course you want it to be assigned.");

                                    cDao = new CourseDao();
                                    clist2 = new ArrayList<Course>();

                                    clist2 = cDao.getListOfCourses();
                                    // exclude the other courses he is already teaching
                                   clist2 = intersectCourses(clist, clist2);
                    
                        if (clist2.size()<1){
                                   System.out.println("There are no more courses to assign.");
                               }  else {
                                    i=1;
                                    for (Course c : clist2) {
                                        System.out.println("["+i+"]: "+c);
                                        i++;
                                    }

                              System.out.print("Enter your option here: ");
                            idx = getInput(input);

                            while (idx > clist2.size() || idx < 0) {
                                System.out.print("\nPlease select a valid number: ");
                                idx = getInput(input);
                            }
                            cid = clist2.get(idx - 1).getId();
                        
                            
                          apcDao.updateAssignmentPerCourseById(cid2, aid, cid);
                        }
                     }
                 System.out.print("\nDo you want to change another Assignment per course? [y] or [n]: ");
                   } while ((!(input.next()).toLowerCase().equals("n"))); 
                 break;
             
            
             case 3: // Insert
                 do{
                 System.out.println("Please select the Assignment you want to add to a course.");
                 aDao = new AssignmentDao();
                apcDao = new AssignmentsPerCourseDao();
                alist = new ArrayList<Assignment>();
                alist = aDao.getListOfAssignments();
                     
                          i = 1;
                        for (Assignment a : alist) {
                         System.out.println("["+i+"]: "+a);
                        i++;
                        }
                    System.out.print("Enter your option here: ");
                    idx = getInput(input);
                    while (idx > alist.size() || idx < 0) {
                        System.out.print("\nPlease select a valid number: ");
                        idx = getInput(input);
                    }
                    aid = alist.get(idx-1).getId();
                    
                    
                       System.out.println("\nPlease select the new course you want to add the Assignment.");
                                   
                                    cDao = new CourseDao();
                                    clist = new ArrayList<Course>();

                                    clist = cDao.getListOfCourses();
                                    clist2 = apcDao.getCoursesPerAssignmentById(aid);                                    
                                    clist2 = intersectCourses(clist, clist2);
                                    
                                     if (clist2.size()<1){
                                   System.out.println("There are no more courses to be assigned.");
                               }  else {
                                    i=1;
                                    for (Course c : clist2) {
                                        System.out.println("["+i+"]: "+c);
                                        i++;
                                    }

                                    System.out.print("Enter your option here: ");
                                        idx = getInput(input);

                                        while (idx > clist2.size() || idx < 0) {
                                            System.out.print("\nPlease select a valid number: ");
                                            idx = getInput(input);
                                        }
                                        cid = clist2.get(idx-1).getId(); 
                                    
                                           apcDao.insertAssignmentPerCourse(aid, cid);
                                     }
                    
                 System.out.print("\nDo you want to add another Assignment to a course? [y] or [n]: ");
                   } while ((!(input.next()).toLowerCase().equals("n"))); 
                 break;
                 
            case 4: // Delete
                do {
                    System.out.println("\nPlease select the Assignment you want to delete from a course.");
                    aDao = new AssignmentDao();
                    apcDao = new AssignmentsPerCourseDao();
                    alist = new ArrayList<Assignment>();
                    alist = aDao.getListOfAssignments();

                    i = 1;
                    for (Assignment a : alist) {
                        System.out.println("[" + i + "]: " + a);
                        i++;
                    }
                    System.out.print("Enter your option here: ");
                    idx = getInput(input);
                    while (idx > alist.size() || idx < 0) {
                        System.out.print("\nPlease select a valid number: ");
                        idx = getInput(input);
                    }
                    aid = alist.get(idx - 1).getId();

                    System.out.println("\nPlease select the course that you want to delete the Assignment.");

                    cDao = new CourseDao();
                    clist = new ArrayList<Course>();

                    clist = apcDao.getCoursesPerAssignmentById(aid);
                    if (clist.isEmpty()) {
                        System.out.println("The Assignment is not appointed to any course.");
                    } else {
                        i = 1;
                        for (Course c : clist) {
                            System.out.println("[" + i + "]: " + c);
                            i++;
                        }

                        System.out.print("Enter your option here: ");
                        idx = getInput(input);

                        while (idx > clist.size() || idx < 0) {
                            System.out.print("\nPlease select a valid number: ");
                            idx = getInput(input);
                        }
                        cid = clist.get(idx - 1).getId();

                        System.out.print("Do you want to proceed? [y] or [n]: ");
                        if ((!(input.next()).equals("n"))) {
                            apcDao.deleteAssignmentsFromCourseByIds(cid, aid);
                        } else {
                            System.out.println("Deletion canceled.");
                        }
                    }
                    System.out.print("\nDo you want to delete another Assignment from a course? [y] or [n]: ");
                } while ((!(input.next()).toLowerCase().equals("n")));

                break;

            case 5:
                break;
        }
    }

     
     private void scheduleCrud(int opt){
         CourseDao cDao = new CourseDao();
        ArrayList<Course> clist = new  ArrayList<Course>();
        ArrayList<Course> clist2 = new  ArrayList<Course>();
        AssignmentDao aDao = new AssignmentDao();
        ArrayList<Assignment> alist = new ArrayList<Assignment>();
        AssignmentsPerCourseDao apcDao;
        int cid;
        int aid;
        int i;
        int idx;
                if ((cDao.getListOfCourses().isEmpty()) || (aDao.getListOfAssignments().isEmpty())) {
            System.out.println("There are no Courses or Assignments!");
            opt = 5;
        }
               
          switch(opt){
             
             case 1: // View
                 do{
                  System.out.println("\nPlease select the course you want to view the schedule.");

                cDao = new CourseDao();
                clist = new ArrayList<Course>();
                
                clist = cDao.getListOfCourses();
                i=1;
                for (Course c : clist) {
                    System.out.println("["+i+"]: "+c);
                    i++;
                }
                
                System.out.print("Enter your option here: ");
                    idx = getInput(input);
                    
                    while (idx > clist.size() || idx < 0) {
                        System.out.print("\nPlease select a valid number: ");
                        idx = getInput(input);
                    }
                    cid = clist.get(idx-1).getId(); 
                    
                    schedulePerCourse(cid);
                
                    
                    System.out.print("\nDo you want to to view the schedule from another course? [y] or [n]: ");
                } while ((!(input.next()).toLowerCase().equals("n")));

                break;
        
                case 2: // Edit
                 do{
                System.out.println("\nPlease select the course you want to edit the schedule for.");

                cDao = new CourseDao();
                clist = new ArrayList<Course>();
                
                clist = cDao.getListOfCourses();
                if (clist.isEmpty()){
                    System.out.println("There are no courses. Add new courses.");
                } else {
                i=1;
                for (Course c : clist) {
                    System.out.println("["+i+"]: "+c);
                    i++;
                }
                
                System.out.print("Enter your option here: ");
                    idx = getInput(input);
                    
                    while (idx > clist.size() || idx < 0) {
                        System.out.print("\nPlease select a valid number: ");
                        idx = getInput(input);
                    }
                    cid = clist.get(idx-1).getId(); 
                    
                    
                    editSchedulePerCourse(cid);
                    
                    System.out.print("\n\nDo you also want to edit the dates for corresponding Assignments? [y] or [n]: ");
                            if ((!(input.next()).toLowerCase().equals("n"))) {
                      
                        do {
                             
                                System.out.println("\nPlease select the Assignment of the course you want to edit.");

                                apcDao = new AssignmentsPerCourseDao();
                                alist = new ArrayList<Assignment>();

                                alist = apcDao.getAssignmentsPerCourseById(cid);
                                if (alist.isEmpty()) {
                                    System.out.println("There are no assignments for this course. Add assignments to this course.");
                                } else {
                                    i = 1;
                                    for (Assignment a : alist) {
                                        System.out.println("[" + i + "]: " + a);
                                        i++;
                                    }

                                      System.out.print("Enter your option here: ");
                                      idx = getInput(input);

                                      while (idx > alist.size() || idx < 0) {
                                          System.out.print("\nPlease select a valid number: ");
                                          idx = getInput(input);
                                      }
                                      aid = alist.get(idx - 1).getId();

                                      editSubmitDate(aid);
                                  }

                                  System.out.print("\nDo you want to to edit the dates for another Assignment? [y] or [n]: ");
                              } while ((!(input.next()).toLowerCase().equals("n")));
                          }
                      }
                      System.out.print("\nDo you want to to edit the schedule from another course? [y] or [n]: ");
                  } while ((!(input.next()).toLowerCase().equals("n")));

                  break;

              case 5:
                    break;
          
          }
          
    }
     
     
     
    private ArrayList<Course> intersectCourses(ArrayList<Course> clist1, ArrayList<Course> clist2){
        ArrayList<Integer> idC1 = new ArrayList<Integer>();
         ArrayList<Integer> idC2 = new ArrayList<Integer>();
         ArrayList<Course> interlist = new ArrayList<Course>();
         CourseDao cDao = new CourseDao();
        
         for (Course c1 : clist1) {
            idC1.add(c1.getId());
        }
        
        for (Course c2 : clist2) {
            idC2.add(c2.getId());
        }
        
        if (idC2.size()>= idC1.size()){
            idC2.removeAll(idC1);
            for(int i :idC2){
            interlist.add(cDao.getCourseById(i));
        }
            
        } else {
            idC1.removeAll(idC2);
            for(int i :idC1){
            interlist.add(cDao.getCourseById(i));
        }
        }
        
        return interlist;
    }
    
    
    private String userNameGenerator(String firstname, String surname){
        CheckIdDao ckDao = new CheckIdDao();
        String username = firstname.substring(0, 1)+"."+surname;
        int matches = ckDao.checkUserName(username);
        if (matches >0){
        username = username + (matches++);
        }
        return (username);
    }
    
      private void editSchedulePerCourse(int cid){
          CourseDao cDao = new CourseDao();
          String cStartDate;
          String cEndDate;
              System.out.print("Do you want to edit the Start Date of the course? [y] or [n]: ");
                        if ((!(input.next()).equals("n"))){
                            System.out.print("Insert a new Start Date for the course(yyyy-MM-dd): ");
                            cStartDate = input.next();
                        } else cStartDate = cDao.getCourseById(cid).getStartDate();
                        
                        System.out.print("Do you want to edit the End Date of the course? [y] or [n]: ");
                        if ((!(input.next()).equals("n"))){
                            System.out.print("Insert a new End Date for the course(yyyy-MM-dd): ");
                            cEndDate = input.next();
                        } else cEndDate = cDao.getCourseById(cid).getEndDate();
                        
                        
                         cDao.updateCourseById(cid, cDao.getCourseById(cid).getTitle(), cDao.getCourseById(cid).getStream(), cDao.getCourseById(cid).getType(), cStartDate, cEndDate);
                        
                        System.out.println("Here is the edited course:");
                        System.out.println(cDao.getCourseById(cid));
            
     }
    
      private void  editSubmitDate(int aid){
          AssignmentDao aDao = new AssignmentDao();
          String  aSubmissionDate = aDao.getAssignmentById(aid).getDate();
           System.out.print("Do you want to change the submission date of the assignment? [y] or [n]: ");
                        if ((!(input.next()).equals("n"))){
                            System.out.print("Insert a new submission date in(yyyy-MM-dd): ");
                            aSubmissionDate = input.next();
                        } 
                        
                        aDao.updateAssignmentById(aid, aDao.getAssignmentById(aid).getTitle(), aDao.getAssignmentById(aid).getDescr(), aSubmissionDate, aDao.getAssignmentById(aid).getMark());
      }
    
    private void schedulePerCourse(int cid){
        CourseDao cDao = new CourseDao();
        AssignmentsPerCourseDao apcDao = new AssignmentsPerCourseDao();
        LocalDate someDate;
        LocalDate submitDate;
        TemporalField woy = WeekFields.ISO.weekOfWeekBasedYear(); 
        int i = 0;
        System.out.print("Do you want to check for today? [y]or[n]: ");
        if ((!(input.next()).toLowerCase().equals("n"))){
            
            someDate = LocalDate.now();
        } else {
            System.out.print("Please enter a date in the format(yyyy-MM-dd): ");
            String someStringDate = input.next();
            while (!(isInDateFormat(someStringDate))){
                someStringDate = input.next();
            }
            someDate = LocalDate.parse(someStringDate, formatter);
        }
        
        LocalDate startDate = LocalDate.parse((cDao.getCourseById(cid).getStartDate()), formatter);
        LocalDate endDate = LocalDate.parse((cDao.getCourseById(cid).getEndDate()), formatter);
        
        if (someDate.isBefore(startDate)){
            System.out.println("This course hasn't started yet!");
        } else if (someDate.isAfter(endDate)){
            System.out.println("This course has been completed!");
        } else {
            System.out.println("This course is ongoing.");
            System.out.println("This is week number "+(someDate.get(woy)-startDate.get(woy))+" of the course.");
            System.out.println("There are still "+(endDate.get(woy)-someDate.get(woy))+" weeks left.");
            System.out.println("There are "+(apcDao.getAssignmentsPerCourseById(cid).size())+" assignments appointed to this course.");
            for (Assignment a : apcDao.getAssignmentsPerCourseById(cid)) {
               submitDate = LocalDate.parse(a.getDate(), formatter) ;
              
               if ( someDate.isBefore(submitDate)){
                   i++;
                   if(sameWeek(submitDate, someDate)){
                       System.out.println(a.getTitle() + " " + a.getDescr() + " should be submitted by " + submitDate);
                   }
                }
            } System.out.println("Assignments left until the end of the course: "+i);
        }
    }
    
    private boolean isInDateFormat(String stringDate) {
        Pattern pattern = Pattern.compile("\\d{4}-\\d{2}-\\d{2}");
        Matcher matcher = pattern.matcher(stringDate);

        if (!matcher.matches()) {

            System.out.print("Please enter a date in the format(yyyy-MM-dd): ");
            return false;
        } else {
            return true;
        }

    }
    
     private boolean sameWeek(LocalDate date1,LocalDate date2){
            TemporalField woy = WeekFields.ISO.weekOfWeekBasedYear(); 
              if (date1.get(woy) == date2.get(woy)){
                  return true;
              }
            return false;
        }
    
}
