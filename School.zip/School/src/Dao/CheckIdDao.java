package Dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import school.entities.Student;


public class CheckIdDao extends GeneralDao {

    
    
     public int checkStudentId(String user, String pass){
        String query = "SELECT * FROM students WHERE s_user = ? AND s_pass = ? ";
        int studentId = 0;
           PreparedStatement pst = null;
           ResultSet rs = null;
        try {
            pst = getConnection().prepareStatement(query);
            pst.setString(1, user);
            pst.setString(2, pass);
            rs = pst.executeQuery();
            
            if(rs.next()){
                 studentId = rs.getInt(1);
            } 
//                else{
//                //System.out.println("No student match");
//               // System.out.println("id= "+studentId);
//            }
                } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                rs.close();
                pst.close();
                closeConnection();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        return studentId;     
    }
    
    
      public int checkTrainerId(String user, String pass){
        String query = "SELECT * FROM trainers WHERE t_user = ? AND t_pass = ? ";
        int trainerId = 0;
           PreparedStatement pst = null;
           ResultSet rs = null;
        try {
            pst = getConnection().prepareStatement(query);
            pst.setString(1, user);
            pst.setString(2, pass);
            rs = pst.executeQuery();
            
            if(rs.next()){
                 trainerId = rs.getInt(1);
            } 
//            else{
//                System.out.println("No trainer match");
//                System.out.println("id= "+trainerId);
//            }
                } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                rs.close();
                pst.close();
                closeConnection();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        return trainerId;     
    }
    
      
      public int checkHeadMasterId(String user, String pass){
        String query = "SELECT * FROM HeadMaster WHERE h_user = ? AND h_pass = ? ";
        int headmasterId = 0;
           PreparedStatement pst = null;
           ResultSet rs = null;
        try {
            pst = getConnection().prepareStatement(query);
            pst.setString(1, user);
            pst.setString(2, pass);
            rs = pst.executeQuery();
            
            if(rs.next()){
                 headmasterId = rs.getInt(1);
            } 
//            else{
//                System.out.println("No master match");
//                System.out.println("id= "+headmasterId);
//            }
                } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                rs.close();
                pst.close();
                closeConnection();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        return headmasterId;     
    }
      
      
      public int checkUserName(String user){
          int numOfMatches = 0;
          user = user.toLowerCase().trim();
          String query1 = "SELECT * FROM students WHERE s_user = ? ";
          String query2 = "SELECT * FROM trainers WHERE t_user = ? ";
          String query3 = "SELECT * FROM HeadMaster WHERE h_user = ? ";
          PreparedStatement pst = null;
          ResultSet rs = null;
           try {
            pst = getConnection().prepareStatement(query1);
            pst.setString(1, user);
           
            rs = pst.executeQuery();
             while(rs.next()){
                 numOfMatches++;
             }
                } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                rs.close();
                pst.close();
                closeConnection();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
          
          try {
            pst = getConnection().prepareStatement(query2);
            pst.setString(1, user);
           
            rs = pst.executeQuery();
             while(rs.next()){
                 numOfMatches++;
             }
                } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                rs.close();
                pst.close();
                closeConnection();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
          
          
          try {
            pst = getConnection().prepareStatement(query3);
            pst.setString(1, user);
           
            rs = pst.executeQuery();
             while(rs.next()){
                 numOfMatches++;
             }
                } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                rs.close();
                pst.close();
                closeConnection();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
          
          
          return numOfMatches;
      }
    
}
