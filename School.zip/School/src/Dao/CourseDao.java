package Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import school.entities.Course;


public class CourseDao {

    private final String URL = "jdbc:mysql://localhost:3306/Private_School?serverTimezone=UTC"; 
    private final String USERNAME = "root";
    private final String PASS = "1234";
    private Connection conn;
    
    
     private Connection getConnection(){
        try {
            conn = DriverManager.getConnection(URL, USERNAME, PASS);
         //   System.out.print(". ");
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return conn;
    }
    
    private void closeConnection(){
        try {
            conn.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    
    
    public ArrayList<Course> getListOfCourses(){
        ArrayList<Course> list = new ArrayList();
        String query = "select * from courses";
        try {
            Statement st = getConnection().createStatement();
            ResultSet rs = st.executeQuery(query);
            while(rs.next()){
                Course c = new Course(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6));
                
                
                list.add(c);
            }
            rs.close();
            st.close();
            //conn.close();
            closeConnection();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return list;
    }
    
    
    
    public Course getCourseById(int cid){
        String query = "SELECT * FROM courses WHERE id = ?";
        Course c = new Course();
           PreparedStatement pst = null;
           ResultSet rs = null;
        try {
            pst = getConnection().prepareStatement(query);
            pst.setInt(1, cid);
            rs = pst.executeQuery();
            rs.next();
            
            
            c.setId(rs.getInt(1));
            c.setTitle(rs.getString(2));
            c.setStream(rs.getString(3));
            c.setType(rs.getString(4));
            c.setStartDate(rs.getString(5));
            c.setEndDate(rs.getString(6));
            
            
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                rs.close();
                pst.close();
                closeConnection();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        return c;

    }
    
    
      
    public void insertCourse(String title, String stream, String type, 
            String startDate, String endDate) {
        String query = "INSERT INTO courses (Title,Stream,Ctype,startDate,EndDate) VALUES (?,?,?,?,?)";
        try {
            Connection con = getConnection();
            PreparedStatement pst = con.prepareStatement(query);
            
            pst.setString(1, title);
            pst.setString(2, stream);
            pst.setString(3, type);
            pst.setString(4, startDate);
            pst.setString(5, endDate);
            int result = pst.executeUpdate();
            if(result>0){
                System.out.println("Insert succesful");
            }else{
                System.out.println("not success");
            }
            pst.close();
            closeConnection();
        } catch (SQLException ex) {
             ex.printStackTrace();
        } 
    }
     
     public void updateCourseById(
            int id, String title, String stream, String type, 
            String startDate, String endDate){
        String query = "UPDATE courses SET title = ?, stream = ?, ctype = ?, startDate = ?, endDate = ? WHERE id = ?";
        Connection conn = getConnection();
        PreparedStatement pst = null;
        
        try {
            pst = conn.prepareStatement(query);
            pst.setInt(6, id);
            pst.setString(1, title);
            pst.setString(2, stream);
            pst.setString(3, type);
            pst.setString(4, startDate);
            pst.setString(5, endDate);
            
            int result = pst.executeUpdate();
             if(result>0){
                System.out.println("Successful update for id :"+id);
            }else{
                System.out.println("Course with id "+id+" was not updated");
            }             
        } catch (SQLException ex) {
           ex.printStackTrace();
        }finally {
            try {
                pst.close();
                closeConnection();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
     }
    
    
     public void deleteCourseById(int id){
        String query = "DELETE FROM courses WHERE id = ?";
        Connection conn = getConnection();
        PreparedStatement pst = null;
        try {
            pst = conn.prepareStatement(query);
       
        pst.setInt(1, id);
        int result = pst.executeUpdate();
        if (result>0){
            System.out.println("Number of courses deleted: "+result);
        } else {
            System.out.println("The course with id "+id+" was not found.");
        }
           
         } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                pst.close();
                closeConnection();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

}
