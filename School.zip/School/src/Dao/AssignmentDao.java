package Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import school.entities.Assignment;
import school.entities.Student;


public class AssignmentDao {

    
     private final String URL = "jdbc:mysql://localhost:3306/Private_School?serverTimezone=UTC"; 
    private final String USERNAME = "root";
    private final String PASS = "1234";
    private Connection conn;
    
    private Connection getConnection(){
        try {
            conn = DriverManager.getConnection(URL, USERNAME, PASS);
          //  System.out.print(". ");
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return conn;
    }
    
    private void closeConnection(){
        try {
            conn.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    
    public ArrayList<Assignment> getListOfAssignments(){
        ArrayList<Assignment> list = new ArrayList<Assignment>();
        String query = "select * from assignments";
        try {
            Statement st = getConnection().createStatement();
            ResultSet rs = st.executeQuery(query);
            while(rs.next()){
                Assignment a = new Assignment(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4),rs.getInt(5));
        
                list.add(a);
            }
            rs.close();
            st.close();
            //conn.close();
            closeConnection();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return list;
    }
    
    
        public Assignment getAssignmentById(int id){
        String query = "SELECT * FROM assignments WHERE id = ?";
        Assignment a = new Assignment();
           PreparedStatement pst = null;
           ResultSet rs = null;
        try {
            pst = getConnection().prepareStatement(query);
            pst.setInt(1, id);
            rs = pst.executeQuery();
            rs.next();
            a.setId(rs.getInt(1));
            a.setTitle(rs.getString(2));
            a.setDescr(rs.getString(3));
            a.setDate(rs.getString(4));
            a.setMark(rs.getInt(5));
            
            
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                rs.close();
                pst.close();
                closeConnection();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        return a;     
    }
    
    
    public void deleteAssignmentById(int id){
        String query = "DELETE FROM assignments WHERE id = ?";
        Connection conn = getConnection();
        PreparedStatement pst = null;
        try {
            pst = conn.prepareStatement(query);
            pst.setInt(1, id);
        int result = pst.executeUpdate();
        if (result>0){
            System.out.println("Total assignments deleted: "+result);
        } else {
            System.out.println("The assignment with id "+id+" was not found.");
        }
         } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                pst.close();
                closeConnection();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
    

   
    public void insertAssignment(String title, String descr, String date, int mark){
        String query = "INSERT INTO assignments (title,adescr,submissiondate,mark) VALUES (?,?,?,?)";
        try {
            Connection con = getConnection();
            PreparedStatement pst = con.prepareStatement(query);
           
            pst.setString(1, title);
             pst.setString(2, descr);
              pst.setString(3, date);
              pst.setInt(4, mark);
              
            int result = pst.executeUpdate();
            if(result>0){
                System.out.println("Insert succesful");
            }else{
                System.out.println("not success");
            }
            pst.close();
            closeConnection();
        } catch (SQLException ex) {
             ex.printStackTrace();
        } 
    }
    
    
    public void updateAssignmentById(int id, String title, String descr, String date, int mark){
        String query = "UPDATE assignments SET title = ?, adescr = ?, submissiondate = ?, mark = ? WHERE id = ?";
        Connection conn = getConnection();
        PreparedStatement pst = null;
        
        try {
            pst = conn.prepareStatement(query);
            pst.setInt(5, id);
            pst.setString(1, title);
            pst.setString(2, descr);
            pst.setString(3, date);
            pst.setInt(4, mark);
            
            int result = pst.executeUpdate();
             if(result>0){
                System.out.println("Successful assignment update.");
            }else{
                System.out.println("Assignment was not updated");
            }             
        } catch (SQLException ex) {
           ex.printStackTrace();
        }finally {
            try {
                pst.close();
                closeConnection();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        
        
        
        
    }
    
}
