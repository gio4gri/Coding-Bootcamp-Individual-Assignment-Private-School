package Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import school.entities.Student;
import school.entities.Trainer;


public class TrainerDao {

     private final String URL = "jdbc:mysql://localhost:3306/Private_School?serverTimezone=UTC"; 
    private final String USERNAME = "root";
    private final String PASS = "1234";
    private Connection conn;
    
    private Connection getConnection(){
        try {
            conn = DriverManager.getConnection(URL, USERNAME, PASS);
//            System.out.print(". ");
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return conn;
    }
    
    private void closeConnection(){
        try {
            conn.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    
    public ArrayList<Trainer> getListOfTrainers(){
        ArrayList<Trainer> list = new ArrayList();
        String query = "select * from trainers";
        try {
            Statement st = getConnection().createStatement();
            ResultSet rs = st.executeQuery(query);
            while(rs.next()){
                Trainer t = new Trainer(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4));
                        
                list.add(t);
            }
            rs.close();
            st.close();
            //conn.close();
            closeConnection();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return list;
    }
    
    public void deleteTrainerById(int id){
        String query = "DELETE FROM trainers WHERE id = ?";
        Connection conn = getConnection();
        PreparedStatement pst = null;
        try {
            pst = conn.prepareStatement(query);
            pst.setInt(1, id);
        int result = pst.executeUpdate();
        if (result>0){
            System.out.println("Total trainers deleted: "+result);
        } else {
            System.out.println("The student with id "+id+" was not found.");
        }
         } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                pst.close();
                closeConnection();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
    
    public Trainer getTrainerById(int id){
        String query = "SELECT * FROM trainers WHERE id = ?";
        Trainer t = new Trainer();
           PreparedStatement pst = null;
           ResultSet rs = null;
        try {
            pst = getConnection().prepareStatement(query);
            pst.setInt(1, id);
            rs = pst.executeQuery();
            rs.next();
            t.setId(rs.getInt(1));
            t.setFname(rs.getString(2));
            t.setLname(rs.getString(3));
            t.setSubj(rs.getString(4));
   
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                rs.close();
                pst.close();
                closeConnection();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        return t;     
    }
    
   
    public void insertTrainer(String fname, String lname, String subj, String tUser,String tPass){
        String query = "INSERT INTO trainers (fname,lname,subj,t_user,t_pass) VALUES (?,?,?,?,?)";
        try {
            Connection con = getConnection();
            PreparedStatement pst = con.prepareStatement(query);
    
            pst.setString(1, fname);
             pst.setString(2, lname);
              pst.setString(3, subj);
              pst.setString(4, tUser);
              pst.setString(5, tPass);

              
            int result = pst.executeUpdate();
            if(result>0){
                System.out.println("Insert succesful");
            }else{
                System.out.println("not success");
            }
            pst.close();
            closeConnection();
        } catch (SQLException ex) {
             ex.printStackTrace();
        } 
    }
    
    
    public void updateTrainerById(int id, String fname, String lname, String subj, String tUser){
        String query = "UPDATE trainers SET fname = ?, lname = ?, subj = ?, t_User = ? WHERE id = ?";
        Connection conn = getConnection();
        PreparedStatement pst = null;
        
        try {
            pst = conn.prepareStatement(query);
            pst.setInt(5, id);
            pst.setString(1, fname);
            pst.setString(2, lname);
            pst.setString(3, subj);
            pst.setString(4, tUser);
      
            
            int result = pst.executeUpdate();
             if(result>0){
                System.out.println("Successful trainer update for id :"+id);
            }else{
                System.out.println("Trainer with id "+id+" not updated");
            }             
        } catch (SQLException ex) {
           ex.printStackTrace();
        }finally {
            try {
                pst.close();
                closeConnection();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        
        
        
        
    }
    
    
    
}
