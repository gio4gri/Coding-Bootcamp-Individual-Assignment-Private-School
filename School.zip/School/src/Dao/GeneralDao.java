package Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import school.entities.Assignment;
import school.entities.Course;
import school.entities.Student;
import school.entities.Trainer;


public class GeneralDao {
 private final String URL = "jdbc:mysql://localhost:3306/Private_School?serverTimezone=UTC"; 
    private final String USERNAME = "root";
    private final String PASS = "1234";
    private Connection conn;
    
    protected Connection getConnection(){
        try {
            conn = DriverManager.getConnection(URL, USERNAME, PASS);
          //  System.out.print(". ");
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return conn;
    }
    
    protected void closeConnection(){
        try {
            conn.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    
    
     protected Course getCourse(int id){
        CourseDao cDao = new CourseDao();
       
        return  (cDao.getCourseById(id));
    }
    
    protected Student getStudent(int id){
        StudentDao sDao = new StudentDao();
        return (sDao.getStudentById(id));
    }
    
    protected Assignment getAssignment(int id){
        AssignmentDao aDao = new AssignmentDao();
        return (aDao.getAssignmentById(id));
    }
    
    protected Trainer getTrainer(int id){
        TrainerDao tDao = new TrainerDao();
        return (tDao.getTrainerById(id));
    }
    
    
}
