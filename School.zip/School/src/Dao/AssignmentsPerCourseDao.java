package Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import school.entities.Assignment;
import school.entities.AssignmentsPerCourse;
import school.entities.Course;
import school.entities.Student;
import school.entities.StudentsPerCourse;
import school.entities.TrainersPerCourse;


public class AssignmentsPerCourseDao {

    private final String URL = "jdbc:mysql://localhost:3306/Private_School?serverTimezone=UTC"; 
    private final String USERNAME = "root";
    private final String PASS = "1234";
    private Connection conn;
    
    private Connection getConnection(){
        try {
            conn = DriverManager.getConnection(URL, USERNAME, PASS);
         //   System.out.print(". ");
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return conn;
    }
    
    private void closeConnection(){
        try {
            conn.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    
    
       public ArrayList<AssignmentsPerCourse> getListOfAssignmentsPerCourse(){
        ArrayList<AssignmentsPerCourse> list = new ArrayList<AssignmentsPerCourse>();
        String query = "select * from assignmentspercourse";
        try {
            Statement st = getConnection().createStatement();
            ResultSet rs = st.executeQuery(query);
            while(rs.next()){
               AssignmentsPerCourse apc = new AssignmentsPerCourse();
                    
                    apc.setId(rs.getInt(1));
                    apc.setAssignment(getAssignment(rs.getInt(2)));
                    apc.setCourse(getCourse(rs.getInt(3)));
         
                list.add(apc);
            }
            rs.close();
            st.close();
            //conn.close();
            closeConnection();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return list;
    }
    
       
         public ArrayList<Course> getCoursesPerAssignmentById(int aid){
        ArrayList<Course> list = new ArrayList<Course>();
        String query = "SELECT * FROM assignmentspercourse WHERE fk_as_id = ?";
      
           PreparedStatement pst = null;
           ResultSet rs = null;
        try {
            pst = getConnection().prepareStatement(query);
            pst.setInt(1, aid);
            rs = pst.executeQuery();
          
             while (rs.next()) {
              
                 AssignmentsPerCourse apc = new AssignmentsPerCourse();
                
                apc.setCourse(getCourse(rs.getInt(3)));
                list.add(apc.getCourse());
            }
            
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                rs.close();
                pst.close();
                closeConnection();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        return list;     
    }
       
         public int getIdForAssignmentsPerCourse(int cid, int aid){
        int id = 0;
        String query = "SELECT * FROM assignmentspercourse WHERE fk_cr_id = ? AND fk_as_id = ? ";
      
           PreparedStatement pst = null;
           ResultSet rs = null;
        try {
            pst = getConnection().prepareStatement(query);
            pst.setInt(1, cid);
            pst.setInt(2, aid);
            rs = pst.executeQuery();
            rs.next();
             
            id = rs.getInt(1);
            
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                rs.close();
                pst.close();
                closeConnection();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        return id; 
        }
       
       
        public ArrayList<Assignment> getAssignmentsPerCourseById(int cid){
        ArrayList<Assignment> list = new ArrayList<Assignment>();
        String query = "SELECT * FROM assignmentspercourse WHERE fk_cr_id = ?";
      
           PreparedStatement pst = null;
           ResultSet rs = null;
        try {
            pst = getConnection().prepareStatement(query);
            pst.setInt(1, cid);
            rs = pst.executeQuery();
          
             while (rs.next()) {
                AssignmentsPerCourse apc = new AssignmentsPerCourse();

                apc.setAssignment(getAssignment(rs.getInt(2)));
                list.add(apc.getAssignment());
            }
            
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                rs.close();
                pst.close();
                closeConnection();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        return list;     
    }
           
        
            public void deleteAssignmentsFromCourseById(int id){
        String query = "DELETE FROM assignmentspercourse WHERE id = ?";
        Connection conn = getConnection();
        PreparedStatement pst = null;
        try {
            pst = conn.prepareStatement(query);
            pst.setInt(1, id);
        int result = pst.executeUpdate();
        if (result>0){
            System.out.println("Total assignments per course deleted: "+result);
        } else {
            System.out.println("The assignment per course was not found.");
        }
         } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                pst.close();
                closeConnection();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
       
        public void deleteAssignmentsFromCourseByIds(int cid, int aid){
        String query = "DELETE FROM assignmentspercourse WHERE fk_cr_id = ? AND fk_as_id = ?";
        Connection conn = getConnection();
        PreparedStatement pst = null;
        try {
            pst = conn.prepareStatement(query);
            pst.setInt(1, cid);
            pst.setInt(2, aid);
        int result = pst.executeUpdate();
        if (result>0){
            System.out.println("Total assignments per course deleted "+result);
        } else {
            System.out.println("The assignment per course was not found.");
        }
         } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                pst.close();
                closeConnection();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
      
        
        public void insertAssignmentPerCourse(int aid, int cid){
        String query = "INSERT INTO assignmentspercourse (fk_as_id,fk_cr_id) VALUES (?,?)";
        try {
            Connection con = getConnection();
            PreparedStatement pst = con.prepareStatement(query);

              pst.setInt(1, aid);
              pst.setInt(2, cid);
              
            int result = pst.executeUpdate();
            if(result>0){
                System.out.println("Insert succesful");
            }else{
                System.out.println("not success");
            }
            pst.close();
            closeConnection();
        } catch (SQLException ex) {
             ex.printStackTrace();
        } 
    }
        
          public void updateAssignmentPerCourseById(int id, int aid, int cid){
        String query = "UPDATE assignmentspercourse SET fk_as_id = ?, fk_cr_id = ? WHERE id = ?";
        Connection conn = getConnection();
        PreparedStatement pst = null;
        
        try {
            pst = conn.prepareStatement(query);
           
            pst.setInt(1, aid);
            pst.setInt(2, cid);
            pst.setInt(3, id);
            
            int result = pst.executeUpdate();
             if(result>0){
                System.out.println("Successful update." );
            }else{
                System.out.println("Not updated");
            }             
        } catch (SQLException ex) {
           ex.printStackTrace();
        }finally {
            try {
                pst.close();
                closeConnection();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        }
        
        
        
        
    private Course getCourse(int id){
        CourseDao cDao = new CourseDao();
       
        return  (cDao.getCourseById(id));
    }
       
    private Assignment getAssignment(int id){
        AssignmentDao aDao = new AssignmentDao();
        return (aDao.getAssignmentById(id));
    }
    
    
    
}
