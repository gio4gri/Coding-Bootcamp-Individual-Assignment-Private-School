package Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import school.entities.Assignment;
import school.entities.AssignmentsPerCourse;
import school.entities.Course;
import school.entities.Student;
import school.entities.Trainer;
import school.entities.TrainersPerCourse;


public class TrainersPerCourseDao {

       private final String URL = "jdbc:mysql://localhost:3306/Private_School?serverTimezone=UTC"; 
    private final String USERNAME = "root";
    private final String PASS = "1234";
    private Connection conn;
    
    private Connection getConnection(){
        try {
            conn = DriverManager.getConnection(URL, USERNAME, PASS);
//            System.out.print(". ");
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return conn;
    }
    
    private void closeConnection(){
        try {
            conn.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    
    
       public ArrayList<TrainersPerCourse> getListOfTrainersPerCourse(){
        ArrayList<TrainersPerCourse> list = new ArrayList<TrainersPerCourse>();
        String query = "select * from trainerspercourse";
        try {
            Statement st = getConnection().createStatement();
            ResultSet rs = st.executeQuery(query);
            while(rs.next()){
               TrainersPerCourse tpc = new TrainersPerCourse();
                    
                tpc.setId(rs.getInt(1));
                tpc.setCourse(getCourse(rs.getInt(2)));
                tpc.setTrainer(getTrainer(rs.getInt(3)));

         
                list.add(tpc);
            }
            rs.close();
            st.close();
            //conn.close();
            closeConnection();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return list;
    }
    
       
        public int getIdForTrainersPerCourse(int cid, int tid){
        int id = 0;
        String query = "SELECT * FROM trainerspercourse WHERE fk_c_id = ? AND fk_t_id = ? ";
      
           PreparedStatement pst = null;
           ResultSet rs = null;
        try {
            pst = getConnection().prepareStatement(query);
            pst.setInt(1, cid);
            pst.setInt(2, tid);
            rs = pst.executeQuery();
            rs.next();
             
            id = rs.getInt(1);
            
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                rs.close();
                pst.close();
                closeConnection();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        return id; 
        }
       
         public ArrayList<Course> getCoursesPerTrainerById(int tid){
        ArrayList<Course> list = new ArrayList<Course>();
        String query = "SELECT * FROM trainerspercourse WHERE fk_t_id = ?";
      
           PreparedStatement pst = null;
           ResultSet rs = null;
        try {
            pst = getConnection().prepareStatement(query);
            pst.setInt(1, tid);
            rs = pst.executeQuery();
          
             while (rs.next()) {
                 TrainersPerCourse tpc = new TrainersPerCourse();
                 
                tpc.setCourse(getCourse(rs.getInt(2)));
                
                list.add(tpc.getCourse());
            }
            
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                rs.close();
                pst.close();
                closeConnection();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        return list;     
    }
       

            public ArrayList<Trainer> getTrainersPerCourseById(int cid){
        ArrayList<Trainer> list = new ArrayList<Trainer>();
        String query = "SELECT * FROM trainerspercourse WHERE fk_c_id = ?";
      
           PreparedStatement pst = null;
           ResultSet rs = null;
        try {
            pst = getConnection().prepareStatement(query);
            pst.setInt(1, cid);
            rs = pst.executeQuery();
          
             while (rs.next()) {
                 TrainersPerCourse tpc = new TrainersPerCourse();
                 
                tpc.setTrainer(getTrainer(rs.getInt(3)));
                
                list.add(tpc.getTrainer());
            }
            
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                rs.close();
                pst.close();
                closeConnection();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        return list;     
    }
      
           
            public void deleteTrainersFromCourseById(int id){
        String query = "DELETE FROM trainerspercourse WHERE id = ?";
        Connection conn = getConnection();
        PreparedStatement pst = null;
        try {
            pst = conn.prepareStatement(query);
            pst.setInt(1, id);
        int result = pst.executeUpdate();
        if (result>0){
            System.out.println("Total trainers per course deleted: "+result);
        } else {
            System.out.println("The trainer per course was not found.");
        }
         } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                pst.close();
                closeConnection();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
       
        public void deleteTrainersFromCourseByIds(int cid, int tid){
        String query = "DELETE FROM trainerspercourse WHERE fk_c_id = ? AND fk_t_id = ?";
        Connection conn = getConnection();
        PreparedStatement pst = null;
        try {
            pst = conn.prepareStatement(query);
            pst.setInt(1, cid);
            pst.setInt(2, tid);
        int result = pst.executeUpdate();
        if (result>0){
            System.out.println("Total trainers per course deleted "+result);
        } else {
            System.out.println("The trainer per course was not found.");
        }
         } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                pst.close();
                closeConnection();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
      
        
        public void insertTrainerPerCourse(int tid, int cid){
        String query = "INSERT INTO trainerspercourse (fk_t_id,fk_c_id) VALUES (?,?)";
        try {
            Connection con = getConnection();
            PreparedStatement pst = con.prepareStatement(query);

              pst.setInt(1, tid);
              pst.setInt(2, cid);
              
            int result = pst.executeUpdate();
            if(result>0){
                System.out.println("Insert succesful");
            }else{
                System.out.println("not success");
            }
            pst.close();
            closeConnection();
        } catch (SQLException ex) {
             ex.printStackTrace();
        } 
    }
        
         public void updateTrainerPerCourseById(int id, int tid, int cid){
        String query = "UPDATE trainerspercourse SET fk_t_id = ?, fk_c_id = ? WHERE id = ?";
        Connection conn = getConnection();
        PreparedStatement pst = null;
        
        try {
            pst = conn.prepareStatement(query);
         
            pst.setInt(1, tid);
            pst.setInt(2, cid);
            pst.setInt(3, id);
            
            int result = pst.executeUpdate();
             if(result>0){
                System.out.println("Successful update.");
            }else{
                System.out.println("Not updated");
            }             
        } catch (SQLException ex) {
           ex.printStackTrace();
        }finally {
            try {
                pst.close();
                closeConnection();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        }
        
        
          public void updateAssignmentPerCourseById(int id, int tid, int cid){
        String query = "UPDATE assignmentspercourses SET fk_t_id = ?, fk_c_id = ? WHERE id = ?";
        Connection conn = getConnection();
        PreparedStatement pst = null;
        
        try {
            pst = conn.prepareStatement(query);
           
            pst.setInt(1, tid);
            pst.setInt(2, cid);
            pst.setInt(3, id);
            
            int result = pst.executeUpdate();
             if(result>0){
                System.out.println("Successful update for id :"+id);
            }else{
                System.out.println("Not updated");
            }             
        } catch (SQLException ex) {
           ex.printStackTrace();
        }finally {
            try {
                pst.close();
                closeConnection();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        }
        
        
        
        
    private Course getCourse(int id){
        CourseDao cDao = new CourseDao();
       
        return  (cDao.getCourseById(id));
    }
       
    private Trainer getTrainer(int id){
        TrainerDao tDao = new TrainerDao();
        return (tDao.getTrainerById(id));
    }
    
    
    
}
