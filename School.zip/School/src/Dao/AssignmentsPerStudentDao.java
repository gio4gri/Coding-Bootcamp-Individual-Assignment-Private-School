package Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import school.entities.*;

public class AssignmentsPerStudentDao {

    private final String URL = "jdbc:mysql://localhost:3306/Private_School?serverTimezone=UTC";
    private final String USERNAME = "root";
    private final String PASS = "1234";
    private Connection conn;

    private Connection getConnection() {
        try {
            conn = DriverManager.getConnection(URL, USERNAME, PASS);
       //     System.out.print(". ");
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return conn;
    }

    private void closeConnection() {
        try {
            conn.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public ArrayList<AssignmentsPerStudent> getListOfAssignmentsPerStudent() {
        ArrayList<AssignmentsPerStudent> list = new ArrayList<AssignmentsPerStudent>();
        String query = "SELECT * FROM assignmentsperstudent as aps "
                + "inner join studentspercourse as spc on spc.id = aps.fk_spc_id "
                + "inner join assignmentspercourse as apc on apc.id = aps.fk_apc_id";
        try {
            Statement st = getConnection().createStatement();
            ResultSet rs = st.executeQuery(query);
            while (rs.next()) {
                AssignmentsPerStudent aps = new AssignmentsPerStudent();

                aps.setId(rs.getInt(1));
                aps.setStudent(getStudent(rs.getInt(7)));
                aps.setCourse(getCourse(rs.getInt(8)));
                aps.setAssignment(getAssignment(rs.getInt(10)));
                aps.setSubmitted(rs.getBoolean(4));
                aps.setMark(rs.getInt(5));
                
                list.add(aps);
            }
            rs.close();
            st.close();
            //conn.close();
            closeConnection();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return list;
    }
    
      public ArrayList<AssignmentsPerStudent>  getListOfAssignmentsPerStudentId(int sid) {
        ArrayList<AssignmentsPerStudent>  list = new ArrayList<AssignmentsPerStudent> ();
        String query = "SELECT * FROM assignmentsperstudent as aps inner join studentspercourse as spc on spc.id = aps.fk_spc_id inner join assignmentspercourse as apc on apc.id = aps.fk_apc_id WHERE spc.fk_s_id = ?";
        
            PreparedStatement pst = null;
            ResultSet rs = null;
        try {
            pst = getConnection().prepareStatement(query);
            pst.setInt(1, sid);
            rs = pst.executeQuery();
            
            while (rs.next()) {
                 AssignmentsPerStudent aps = new AssignmentsPerStudent();

                aps.setId(rs.getInt(1));
                aps.setStudent(getStudent(rs.getInt(7)));
                aps.setCourse(getCourse(rs.getInt(8)));
                aps.setAssignment(getAssignment(rs.getInt(10)));
                aps.setSubmitted(rs.getBoolean(4));
                aps.setMark(rs.getInt(5));
                 
                list.add(aps);
            }
            rs.close();
            pst.close();
            //conn.close();
            closeConnection();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return list;
    }
    

    public ArrayList<Assignment> getListOfAssignmentsPerStudentId2(int sid) {
        ArrayList<Assignment> list = new ArrayList<Assignment>();
        String query = "SELECT * FROM assignmentsperstudent as aps inner join studentspercourse as spc on spc.id = aps.fk_spc_id inner join assignmentspercourse as apc on apc.id = aps.fk_apc_id WHERE spc.fk_s_id = ?";
        
            PreparedStatement pst = null;
            ResultSet rs = null;
        try {
            pst = getConnection().prepareStatement(query);
            pst.setInt(1, sid);
            rs = pst.executeQuery();
            
            while (rs.next()) {
                Assignment a = new Assignment();

              
                 a = getAssignment(rs.getInt(10));

                list.add(a);
            }
            rs.close();
            pst.close();
            //conn.close();
            closeConnection();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return list;
    }

    
     public void updateMarkAssignmentPerStudentById(int sid, int aid, int tid, int m){
        String query = "UPDATE assignmentsperstudent as aps inner join studentspercourse as spc on spc.id = aps.fk_spc_id inner join assignmentspercourse as apc on apc.id = aps.fk_apc_id inner join TrainersPerCourse as tpc on tpc.fk_c_id = spc.fk_c_id SET aps.mark = ? WHERE spc.fk_s_id = ? and apc.fk_as_id = ? and tpc.fk_t_id = ?"; 
        Connection conn = getConnection();
        PreparedStatement pst = null;
        
        try {
            pst = conn.prepareStatement(query);
           
            pst.setInt(1, m);
            pst.setInt(2, sid);
            pst.setInt(3, aid);
            pst.setInt(4, tid);
            
            int result = pst.executeUpdate();
             if(result>0){
                System.out.println("Marked succesfully");
            }else{
                System.out.println("Not marked.");
            }             
        } catch (SQLException ex) {
           ex.printStackTrace();
        }finally {
            try {
                pst.close();
                closeConnection();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        } 
    
    
  
    
      public void updateAssignmentPerStudentById(int sid, int aid){
        String query = "UPDATE assignmentsperstudent AS aps INNER JOIN studentspercourse AS spc ON spc.id = aps.fk_spc_id INNER JOIN assignmentspercourse AS apc ON apc.id = aps.fk_apc_id SET aps.submitted = true WHERE spc.fk_s_id = ? AND apc.fk_as_id = ?"; 
        Connection conn = getConnection();
        PreparedStatement pst = null;
        
        try {
            pst = conn.prepareStatement(query);
           
            pst.setInt(1, sid);
            pst.setInt(2, aid);
            
            int result = pst.executeUpdate();
             if(result>0){
                System.out.println("Assignment submitted");
            }else{
                System.out.println("Not submitted");
            }             
        } catch (SQLException ex) {
           ex.printStackTrace();
        }finally {
            try {
                pst.close();
                closeConnection();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        }  
    
    
    private Course getCourse(int id) {
        CourseDao cDao = new CourseDao();

        return (cDao.getCourseById(id));
    }

    private Student getStudent(int id) {
        StudentDao sDao = new StudentDao();
        return (sDao.getStudentById(id));
    }

    private Assignment getAssignment(int id) {
        AssignmentDao aDao = new AssignmentDao();
        return (aDao.getAssignmentById(id));
    }

}
